# Order Search API

## Problem
Support staff cannot find an order without an exact order id. They resort to
querying the database directly, which is slow and unaudited.

## Scope
A read-only search endpoint over existing orders: by customer email, by date
range, and by partial reference. Results paginated.

## Out of scope
Editing orders. Search over archived orders older than 24 months. Any change
to how orders are created.

## Acceptance criteria
- GET /orders/search returns matches for a customer email in under 400ms at p95.
- A date range longer than 90 days is rejected with a clear error.
- Results are paginated at 50 per page with a stable sort.
- A caller scoped to one region never receives another region's orders.

## Constraints
- The existing orders table must not gain an index that slows inserts.
- No new third-party service.

## Non-functional requirements
- p95 under 400ms at 50 requests per second.
- Every query attributable to a caller in the access log.

## Compatibility
Additive only. Existing order endpoints keep their current contracts.

## Dependencies
The regional scoping claim already present on the caller token.

## Open questions
None blocking. Sort tie-breaking beyond created-at is deferred.
