# STUB — not Spec Kit

Placeholder so `preflight` can verify skill discovery. The PoC stubs artifact generation and never invokes Spec Kit.
