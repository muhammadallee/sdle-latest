"""Thin wrapper around scripts/sdle.py — the PoC's only way to touch SDLE.

Three rules, taken from SDLE's invariants and not negotiable in this adapter:

1. Nothing here writes `state.json`, `audit.md` or anything under `.sdle/`.
   Every mutation goes through the engine. (Invariant 6.)
2. Nothing here hardcodes a phase number, gate number or progress fraction.
   They are flow-relative — `Gate 1/8` under GREENFIELD is a different number
   under HOTFIX — so they are always read from `gate show` / `resume`.
3. A refusal (exit 1) is final. It is raised, surfaced and stopped on. It is
   never retried and never worked around.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

EXIT_OK, EXIT_REFUSED, EXIT_USAGE, EXIT_INTEGRITY = 0, 1, 2, 3

_EXIT_LABEL = {
    EXIT_REFUSED: "refused",
    EXIT_USAGE: "usage error",
    EXIT_INTEGRITY: "integrity failure",
}


class EngineError(RuntimeError):
    """A non-zero exit from sdle.py.

    Carries the structured envelope so the UI can render `reason` and
    `message` rather than parsing prose.
    """

    def __init__(self, exit_code: int, reason: str | None, message: str,
                 data: dict, argv: list[str]):
        self.exit_code = exit_code
        self.reason = reason or "unknown"
        self.message = message
        self.data = data
        self.argv = argv
        super().__init__(f"{self.reason}: {message}")

    @property
    def kind(self) -> str:
        return _EXIT_LABEL.get(self.exit_code, f"exit {self.exit_code}")

    @property
    def is_refusal(self) -> bool:
        """Exit 1. A rule said no. Final — never retry."""
        return self.exit_code == EXIT_REFUSED


@dataclass
class Sdle:
    """A bound (project, workitem) the PoC drives."""

    target: Path
    workitem: str | None = None
    session: str = "poc00001"
    calls: list[dict] = field(default_factory=list)

    @property
    def engine_path(self) -> Path:
        return self.target / "scripts" / "sdle.py"

    @property
    def skill_root(self) -> Path:
        return self.target / ".claude" / "skills" / "sdle"

    def for_workitem(self, workitem: str) -> "Sdle":
        self.workitem = workitem
        return self

    # -- the single call site -------------------------------------------
    def __call__(self, *args: str, workitem: str | None = None,
                 session: bool = False) -> dict:
        """Run one engine command. Returns `data`; raises EngineError otherwise."""
        argv = [sys.executable, str(self.engine_path),
                "--project-root", str(self.target),
                "--skill-root", str(self.skill_root)]
        wi = workitem if workitem is not None else self.workitem
        if wi:
            argv += ["--workitem", wi]
        if session:
            argv += ["--session", self.session]
        argv += [str(a) for a in args]

        proc = subprocess.run(argv, capture_output=True, text=True,
                              cwd=str(self.target))
        try:
            envelope = json.loads(proc.stdout)
        except ValueError:
            envelope = {}

        self.calls.append({
            "args": list(args),
            "exit": proc.returncode,
            "reason": envelope.get("reason"),
        })

        if proc.returncode != EXIT_OK:
            raise EngineError(
                proc.returncode,
                envelope.get("reason"),
                envelope.get("message") or proc.stderr.strip()
                or f"sdle exited {proc.returncode}",
                envelope.get("data") or {},
                argv,
            )
        return envelope.get("data") or {}

    # -- read-only helpers the UI renders from --------------------------
    def flow(self) -> dict:
        """The whole graph: phases, gate phases, position. Never hardcoded."""
        return self("flow", "show")

    def resume(self) -> dict:
        """Where are we? Position, progress, pending work, next phase."""
        return self("resume")

    def gate(self, key: str) -> dict:
        """Gate number, total, label and artifact path — flow-relative."""
        return self("gate", "show", "--gate", key)

    def quality_checks(self) -> list[str]:
        """The twelve check ids, read from policy rather than restated."""
        return self("governance", "policy")["policy"]["quality_checks"]

    def has_state(self) -> bool:
        """False before `init`. No status header can be rendered until then."""
        if not self.workitem:
            return False
        return (self.target / "workitems" / self.workitem / ".sdle"
                / "state.json").is_file()


def find_target() -> Path:
    """The project the PoC drives: $SDLE_TARGET, else ./demo-target."""
    raw = os.environ.get("SDLE_TARGET")
    target = Path(raw).resolve() if raw else (Path(__file__).parent
                                              / "demo-target").resolve()
    if not (target / "scripts" / "sdle.py").is_file():
        raise SystemExit(
            f"No SDLE install at {target}.\n"
            "Run:  python setup_demo.py        (creates ./demo-target)\n"
            "or:   set SDLE_TARGET=<your project>"
        )
    return target
