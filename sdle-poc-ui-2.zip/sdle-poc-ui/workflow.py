"""The command sequence, with no UI in it.

Kept separate from app.py so it can be driven headless — `python workflow.py`
runs the whole PoC slice in a terminal and prints what the UI would show. That
is how the sequence was verified before any Chainlit code existed, and it is
how you check a change without clicking through a browser.

The UI supplies three callbacks and owns nothing else:

    on_step(label)  -> context manager for a collapsed step
    on_gate(gate, artifact_text) -> "approve" | ("reject", feedback)
    on_note(text)   -> a line the user should see
"""
from __future__ import annotations

import contextlib
import json
from dataclasses import dataclass
from pathlib import Path

from engine import EngineError, Sdle
from generator import generate

#: Which review type each phase's artifact is recorded under. The engine takes
#: a free string; these are the PoC's, kept in one place rather than inline.
REVIEW_TYPE = {
    "constitution_draft": "constitution_review",
    "spec_draft": "specification_review",
}


@dataclass
class Gate:
    """Everything an approval card needs — all of it read from the engine."""
    key: str
    number: int
    total: int
    label: str
    artifact_path: str
    required: bool

    @property
    def caption(self) -> str:
        return f"Gate {self.number} of {self.total}"


class Workflow:
    def __init__(self, target: Path, on_step, on_gate, on_note):
        self.sdle = Sdle(target)
        self.target = target
        self.on_step = on_step
        self.on_gate = on_gate
        self.on_note = on_note
        self.project = "Order Search API"
        #: Every artifact produced this run, for the sidebar list.
        self.artifacts: list[dict] = []

    # -- bootstrap -------------------------------------------------------
    def requirement_documents(self) -> list[str]:
        """What is on offer. The USER picks; the adapter never chooses."""
        root = self.target / "requirements"
        return sorted(
            p.relative_to(self.target).as_posix()
            for p in root.rglob("*.md")
        ) if root.is_dir() else []

    def bootstrap(self, name: str, sources: list[str],
                  skip_preflight: bool = False) -> dict:
        """create -> bind -> show -> preflight -> scan -> assess -> init."""
        with self.on_step(f"Registering WorkItem “{name}”"):
            data = self.sdle("workitem", "create", "--name", name, workitem=None)
            workitem = data["id"]
            self.sdle.for_workitem(workitem)

        with self.on_step("Binding requirement documents"):
            args = ["requirements", "bind"]
            for src in sources:
                args += ["--source", src]
            if len(sources) > 1:
                # More than one source requires a primary; the engine refuses
                # rather than choosing, and the primary's first `#` heading
                # becomes the project name.
                args += ["--primary", sources[0]]
            self.sdle(*args)
            bound = self.sdle("requirements", "show")
        self.on_note("Bound: " + ", ".join(bound["sources"]))

        if not skip_preflight:
            with self.on_step("Preflight"):
                self.sdle("preflight")

        for source in bound["sources"]:
            with self.on_step(f"Content scan — {source}"):
                self.sdle("scan", "--path", source)

        with self.on_step("Governance assessment"):
            self._assess()

        with self.on_step("Initialising workflow"):
            data = self.sdle("init", session=True)
        return data

    def _assess(self) -> dict:
        """Write an all-PASS proposal and record it.

        STUB. A real run has the model answer the twelve checks from reading
        the document. The check ids are read from the engine's policy, never
        restated here.
        """
        proposal = {
            "governanceInputVersion": "1",
            "quality": {check: {"result": "PASS", "finding": None}
                        for check in self.sdle.quality_checks()},
            "classification": {"type": "enhancement", "flow": "GREENFIELD"},
            "risk": {"signals": ["external_api_surface", "persistent_data_store"],
                     "proposedLevel": "MEDIUM", "uncertainty": "LOW"},
        }
        path = self.target / "governance-input.json"
        path.write_text(json.dumps(proposal, indent=2), encoding="utf-8")
        try:
            return self.sdle("governance", "assess", "--input",
                             "governance-input.json")
        finally:
            path.unlink(missing_ok=True)

    # -- one gated phase -------------------------------------------------
    def run_gated_phase(self, phase: str, gate_key: str) -> str:
        """generate -> record -> review -> show -> DECIDE -> approve/reject.

        Loops on rejection. Returns the phase advanced to.
        """
        gate = self._gate(gate_key)
        attempt, feedback = 1, None
        what = gate.label.split(":")[-1].strip().replace(" Approval", "")

        while True:
            with self.on_step(f"Generating {what}"
                              + ("" if attempt == 1 else f" (attempt {attempt})")):
                path = gate.artifact_path or self._prepare_feature(phase)
                generate(phase, self.target, path,
                         self.project, attempt, feedback)

            if gate.artifact_path is None:
                # Spec Kit artifacts live in a feature directory the engine
                # adopts rather than assumes. Until `feature resolve` runs,
                # `gate show` reports no artifact path and the gate cannot be
                # approved. The stub wrote the directory above; this adopts it.
                with self.on_step("Resolving feature directory"):
                    self.sdle("feature", "resolve", session=True)
                gate = self._gate(gate_key)

            with self.on_step("Recording artifact"):
                self.sdle("artifact", "record", "--phase", phase,
                          "--path", gate.artifact_path, session=True)

            with self.on_step("Recording review"):
                # Not optional: every gate with a resolvable artifact refuses
                # `review_missing` without one. Artifact existence is not
                # evidence of artifact quality.
                self.sdle("artifact", "review",
                          "--path", gate.artifact_path,
                          "--type", REVIEW_TYPE[phase],
                          "--result", "PASS",
                          "--actor-type", "agent",
                          "--actor-name", "poc-stub-generator",
                          session=True)

            # A gate can only be approved while standing at it: `gate approve`
            # refuses `not_at_gate` from the generation phase. So advance into
            # the gate first, then decide. Only done on the first attempt — a
            # rejection leaves the workflow at the gate already.
            if self.sdle.resume()["current_phase"] != gate_key:
                with self.on_step(f"Arriving at {gate.caption}"):
                    self.sdle("advance", "--to", gate_key, session=True)

            gate = self._gate(gate_key)          # re-read: sha changed
            text = (self.target / gate.artifact_path).read_text(encoding="utf-8")
            self._remember(gate, phase, attempt)

            decision = self.on_gate(gate, text)

            if decision == "approve":
                with self.on_step(f"Approving {gate.caption}"):
                    # `gate approve` advances past the gate itself — it calls
                    # apply_advance internally. Advancing again here would
                    # double-step and silently skip the next generation phase,
                    # which is exactly what an early version of this file did.
                    self.sdle("gate", "approve", "--gate", gate.key,
                              session=True)
                break

            _, feedback = decision
            with self.on_step(f"Rejecting {gate.caption}"):
                # `--reason`, not `--comments`: approve and reject do not share
                # a flag name. The rejection reason is recorded in the audit
                # chain, so it is evidence, not a UI nicety.
                self.sdle("gate", "reject", "--gate", gate.key,
                          "--reason", feedback, session=True)
            attempt += 1

        return self.sdle.resume()["current_phase"]

    def _remember(self, gate: "Gate", phase: str, attempt: int) -> None:
        """Keep the newest version of each artifact, not one row per attempt."""
        row = {"path": gate.artifact_path, "phase": phase,
               "title": gate.label.split(":")[-1].strip(),
               "gate": gate.caption, "attempt": attempt,
               "sha": self.sdle.gate(gate.key).get("artifact_sha")}
        for i, existing in enumerate(self.artifacts):
            if existing["path"] == row["path"]:
                self.artifacts[i] = row
                return
        self.artifacts.append(row)

    def _prepare_feature(self, phase: str) -> str:
        """Where a Spec Kit artifact is written before the engine adopts it.

        STUB. A real run has Spec Kit create this directory; `feature resolve`
        then moves it under the WorkItem. The PoC writes it directly so the
        adoption step is still exercised rather than skipped.
        """
        if phase != "spec_draft":
            raise KeyError(f"No artifact path for {phase!r}")
        return "specs/001-order-search/spec.md"

    def _gate(self, key: str) -> Gate:
        d = self.sdle.gate(key)
        return Gate(key=d["gate"], number=d["gate_number"],
                    total=d["gate_total"], label=d["label"],
                    artifact_path=d["artifact_path"], required=d["required"])

    # -- what the progress bar renders from ------------------------------
    def progress(self) -> dict:
        r = self.sdle.resume()
        f = self.sdle.flow()
        return {
            "flow": r["flow"],
            "phase": r["current_phase"],
            "label": r["label"],
            "progress": r["progress"],
            "position": r["position"],
            "phases": f["phases"],
            "gate_phases": f["gate_phases"],
            "gate_total": f["gate_total"],
        }

    # -- what the flow chart renders from --------------------------------
    def flow_view(self) -> dict:
        """One node per phase of the BOUND flow, with its state.

        Everything here is read from the engine. The PoC covers two phases, but
        the chart draws whatever the bound flow contains — so it is already
        correct for HOTFIX's ten phases or BROWNFIELD_DISCOVERY's nineteen,
        with the right gate numbers, without a line changing.
        """
        f = self.sdle.flow()
        r = self.sdle.resume()
        labels = self.sdle("constants")["phase_label"]
        phases = f["phases"]
        here = r["current_phase"]
        idx = phases.index(here) if here in phases else -1

        gate_no = 0
        nodes = []
        for i, phase in enumerate(phases):
            is_gate = phase in f["gate_phases"]
            if is_gate:
                gate_no += 1
            nodes.append({
                "id": phase,
                "label": labels.get(phase, phase),
                "gate": gate_no if is_gate else None,
                "state": ("done" if idx >= 0 and i < idx
                          else "current" if i == idx
                          else "pending"),
                # The PoC stops after gate_spec; everything past it is real in
                # the engine but not driven here. Shown dimmed rather than
                # hidden, because pretending the flow is two phases long would
                # misrepresent the product.
                "in_poc": phase in ("requirements_check", "constitution_draft",
                                    "gate_constitution", "spec_draft",
                                    "gate_spec"),
            })

        return {
            "flow": f["name"],
            "phaseCount": f["phase_count"],
            "gateTotal": f["gate_total"],
            "progress": r["progress"],
            "current": here,
            "nodes": nodes,
            "calls": self.sdle.calls[-60:],
        }

    def artifact_view(self) -> list[dict]:
        """Every artifact this run has produced, newest last."""
        out = []
        for item in self.artifacts:
            path = self.target / item["path"]
            out.append({**item,
                        "exists": path.is_file(),
                        "bytes": path.stat().st_size if path.is_file() else 0,
                        "content": (path.read_text(encoding="utf-8")
                                    if path.is_file() else "")})
        return out


# --------------------------------------------------------------------------
# Headless driver — the PoC slice, no browser involved.
# --------------------------------------------------------------------------

def _headless() -> int:
    import os
    from engine import find_target

    @contextlib.contextmanager
    def step(label):
        print(f"  · {label} …", end="", flush=True)
        try:
            yield
        except EngineError as exc:
            print(f" HALT  {exc.reason}")
            raise
        print(" ok")

    def gate(g: Gate, text: str):
        print(f"\n=== {g.caption}: {g.label} ===")
        print(f"    artifact: {g.artifact_path}  ({len(text)} bytes)")
        print("    " + "\n    ".join(text.splitlines()[:6]))
        print("    …")
        choice = os.environ.get("POC_DECIDE", "approve,approve").split(",")
        pick = choice[gate.calls] if gate.calls < len(choice) else "approve"
        gate.calls += 1
        if pick.startswith("reject"):
            print("    DECISION: reject")
            return ("reject", "Needs an explicit cross-region statement.")
        print("    DECISION: approve")
        return "approve"
    gate.calls = 0

    target = find_target()
    wf = Workflow(target, step, gate, lambda t: print(f"    {t}"))

    print(f"target: {target}\n")
    print("BOOTSTRAP")
    data = wf.bootstrap(
        "Order Search",
        ["requirements/order-search.md"],
        skip_preflight=os.environ.get("SDLE_POC_SKIP_PREFLIGHT") == "1",
    )
    print(f"    -> {data['current_phase']}  {data['progress']}  "
          f"project={data['project_name']!r}")

    for phase, gate_key in (("constitution_draft", "gate_constitution"),
                            ("spec_draft", "gate_spec")):
        p = wf.progress()
        print(f"\nPHASE {p['progress']} — {p['label']}")
        wf.run_gated_phase(phase, gate_key)

    p = wf.progress()
    print(f"\nDONE. Now at {p['progress']} — {p['label']}")
    print(f"engine calls: {len(wf.sdle.calls)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(_headless())
