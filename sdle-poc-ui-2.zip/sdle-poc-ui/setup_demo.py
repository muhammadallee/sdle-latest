"""Create ./demo-target — a disposable project with SDLE installed.

    python setup_demo.py [--force]

Uses the sdle-template payload next door. Nothing here is PoC-specific: it is
the same install the template's install.sh performs, minus Spec Kit (the PoC
stubs generation, so Spec Kit is not exercised).
"""
from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path


def _force_remove(path: Path) -> None:
    """rmtree that survives Windows.

    Git marks objects and pack files read-only. `shutil.rmtree` then fails,
    and with `ignore_errors=True` it fails *silently* and leaves the directory
    behind — so the next mkdir raises FileExistsError and the real cause is
    invisible. Clear the read-only bit and retry instead.
    """
    def clear_readonly(func, target, _exc):
        os.chmod(target, stat.S_IWRITE)
        func(target)

    if not path.exists():
        return
    # `onexc` replaced `onerror` in 3.12; support both rather than pin.
    if sys.version_info >= (3, 12):
        shutil.rmtree(path, onexc=clear_readonly)
    else:
        shutil.rmtree(path, onerror=clear_readonly)

HERE = Path(__file__).parent.resolve()
TARGET = HERE / "demo-target"
PAYLOAD = (HERE.parent / "sdle-template" / "payload").resolve()

# Deliberately free of `set status`, `mark approved`, `skip approval` and
# `advance phase`: those are ordinary requirements English and every one of
# them trips the untrusted-content scan. At bootstrap there is no
# acknowledgement route (it needs state, which `init` has not created), so a
# demo document that trips the scan would stall the PoC on its first run.
REQUIREMENTS = """# Order Search API

## Problem
Support staff cannot find an order without an exact order id. They resort to
querying the database directly, which is slow and unaudited.

## Scope
A read-only search endpoint over existing orders: by customer email, by date
range, and by partial reference. Results paginated.

## Out of scope
Editing orders. Search over archived orders older than 24 months. Any change
to how orders are created.

## Acceptance criteria
- GET /orders/search returns matches for a customer email in under 400ms at p95.
- A date range longer than 90 days is rejected with a clear error.
- Results are paginated at 50 per page with a stable sort.
- A caller scoped to one region never receives another region's orders.

## Constraints
- The existing orders table must not gain an index that slows inserts.
- No new third-party service.

## Non-functional requirements
- p95 under 400ms at 50 requests per second.
- Every query attributable to a caller in the access log.

## Compatibility
Additive only. Existing order endpoints keep their current contracts.

## Dependencies
The regional scoping claim already present on the caller token.

## Open questions
None blocking. Sort tie-breaking beyond created-at is deferred.
"""


def run(*args: str, cwd: Path) -> None:
    subprocess.run(args, cwd=str(cwd), check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main() -> int:
    force = "--force" in sys.argv
    if TARGET.exists():
        if not force:
            print(f"{TARGET} already exists. Re-create it with --force.")
            return 1
        _force_remove(TARGET)

    if not PAYLOAD.is_dir():
        print(f"No payload at {PAYLOAD}. Expected the sdle-template folder "
              f"beside this one.", file=sys.stderr)
        return 1

    TARGET.mkdir(parents=True)
    run("git", "init", "-q", ".", cwd=TARGET)

    (TARGET / "scripts").mkdir()
    for name in ("sdle.py", "sdle.sh", "sdle.ps1"):
        shutil.copy2(PAYLOAD / "scripts" / name, TARGET / "scripts" / name)

    claude = TARGET / ".claude"
    (claude / "skills").mkdir(parents=True)
    shutil.copytree(PAYLOAD / ".claude" / "skills" / "sdle",
                    claude / "skills" / "sdle")
    for sub in ("commands", "agents", "hooks"):
        shutil.copytree(PAYLOAD / ".claude" / sub, claude / sub)
    shutil.copy2(PAYLOAD / ".claude" / "settings.json", claude / "settings.json")

    # Spec Kit: a STUB, not an install. The PoC stubs generation and never
    # invokes Spec Kit, but `preflight` checks that it is present and that its
    # skills are discoverable — so without this the demo halts on
    # `speckit_skills_missing` before it can show anything.
    #
    # This is the same stub SDLE's own test fixtures use. It is enough to make
    # preflight a real check that really passes, rather than a check the PoC
    # skips. Do not mistake it for a Spec Kit installation: see README §"What
    # is faked".
    (TARGET / ".specify" / "memory").mkdir(parents=True)
    (TARGET / ".specify" / "scripts" / "bash").mkdir(parents=True)
    stub = claude / "skills" / "speckit-constitution"
    stub.mkdir(parents=True)
    (stub / "SKILL.md").write_text(
        "# STUB — not Spec Kit\n\nPlaceholder so `preflight` can verify skill "
        "discovery. The PoC stubs artifact generation and never invokes Spec "
        "Kit.\n", encoding="utf-8", newline="\n")

    req = TARGET / "requirements"
    req.mkdir()
    (req / "order-search.md").write_text(REQUIREMENTS, encoding="utf-8",
                                         newline="\n")

    (TARGET / ".gitignore").write_text(
        "workitems/*/.sdle/lock\nworkitems/.active-context.json\n"
        ".claude/settings.local.json\n", encoding="utf-8", newline="\n")

    run("git", "add", "-A", cwd=TARGET)
    run("git", "-c", "user.email=poc@example.com", "-c", "user.name=PoC",
        "commit", "-qm", "Demo target with SDLE installed", cwd=TARGET)

    print(f"Created {TARGET}")
    print("  requirements/order-search.md")
    print("\nNext:  chainlit run app.py -w")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
