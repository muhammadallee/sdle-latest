"""SDLE in a Chainlit UI — proof of concept.

Run:  chainlit run app.py -w

Scope: bootstrap -> Generate Constitution -> Gate 1 -> Generate Specification
-> Gate 2. That slice contains every interaction pattern the full 19-phase
product needs; everything after it is these same patterns repeating.

The UI owns the presentation and nothing else. The command sequence lives in
workflow.py so it can be driven headless (`python workflow.py`) — which is how
it was built and how it should be debugged.

Two things here are load-bearing and easy to get wrong:

* **The workflow runs in a worker thread** (`cl.make_async`). Every engine call
  is a blocking subprocess; running them on the event loop freezes the browser
  and no step ever streams. `cl.run_sync` marshals back to the loop from the
  worker, which is what makes the gate prompt work from inside the thread.
* **Elements are inline, not `ElementSidebar`.** The sidebar renders a custom
  element's title and an empty body; inline elements render correctly.
"""
from __future__ import annotations

import contextlib

import chainlit as cl

from engine import EngineError, find_target
from workflow import Gate, Workflow

WELCOME = """\
## Spec Driven Lifecycle Engine

A governed delivery workflow. You name the work, choose what it is about, and
**decide at every gate** — nothing advances on its own.

The flow panel tracks where you are; switch it to **Engine** to see every
command this page runs. Artifacts collect as they are produced and stay
readable.

*Artifact generation is stubbed in this proof of concept. The engine, the
gates and the audit chain are real.*
"""


# --------------------------------------------------------------------------
# the two panels
# --------------------------------------------------------------------------

async def _panels(wf: Workflow, note: str = "") -> None:
    """Send a fresh flow chart and artifact list.

    Re-sent rather than updated in place: each one is a record of the run at
    that moment, and scrolling back through them reads as a history.
    """
    try:
        flow = wf.flow_view()
    except EngineError:
        return                      # before `init` there is no flow to draw

    elements = [cl.CustomElement(name="FlowChart", props=flow)]
    items = wf.artifact_view()
    if items:
        elements.append(cl.CustomElement(name="Artifacts",
                                         props={"items": items}))
    await cl.Message(content=note, elements=elements, author="SDLE").send()


# --------------------------------------------------------------------------
# callbacks handed to the workflow (called from the worker thread)
# --------------------------------------------------------------------------

def _step(label: str):
    """A collapsed step. The engine call happens inside; its JSON never shows.

    This is the whole "hide the logs" mechanism — SKILL.md's verbosity rules
    say to suppress script invocations, SHA computation and state-write
    narration, and always to show phase start and completion. A collapsed step
    is exactly that split, and the Engine tab is the `verbose on` escape hatch.
    """
    @contextlib.contextmanager
    def ctx():
        # `with cl.Step(...)` raises "no running event loop" here: the sync
        # context manager wants the loop, and this runs in a worker thread.
        # Drive the async form through run_sync, which marshals to the main
        # loop via run_coroutine_threadsafe.
        step = cl.Step(name=label, type="run", show_input=False)
        cl.run_sync(step.__aenter__())
        try:
            yield
        finally:
            cl.run_sync(step.__aexit__(None, None, None))
    return ctx()


def _note_sync(text: str) -> None:
    cl.run_sync(cl.Message(content=text, author="SDLE").send())


async def _gate_card(gate: Gate, text: str) -> str | tuple[str, str]:
    """The decision. Artifact shown IN FULL above the buttons.

    Invariant 4: the user never opens a file to know what they are approving.
    "Hide the logs" must never become "hide the artifact".
    """
    await cl.Message(
        content=(f"### {gate.caption} — {gate.label}\n"
                 f"`{gate.artifact_path}`\n\n---\n\n{text}"),
        author="SDLE",
    ).send()

    res = await cl.AskActionMessage(
        content="**Your decision.** Nothing advances until you choose.",
        actions=[
            cl.Action(name="approve", payload={"d": "approve"},
                      label="✓  Approve"),
            cl.Action(name="reject", payload={"d": "reject"},
                      label="✗  Reject"),
        ],
        timeout=3600,
    ).send()

    # No default. A timeout is not an approval — the engine cannot tell a human
    # from a model, so a silent auto-approve would delete the only guarantee
    # this product has (ADR-007 §3).
    if not res:
        raise TimeoutError("No decision was made.")
    if res.get("payload", {}).get("d") != "reject":
        return "approve"

    ask = await cl.AskUserMessage(
        content="What needs to change? It is recorded in the audit chain.",
        timeout=3600,
    ).send()
    reason = (ask or {}).get("output", "").strip() or "Rejected without detail."
    return ("reject", reason)


def _gate_handler(wf: Workflow):
    def handler(gate: Gate, text: str):
        # Show the artifact in the list before asking, so it can be reopened.
        cl.run_sync(_panels(wf, f"**{gate.caption}** is ready for your decision."))
        return cl.run_sync(_gate_card(gate, text))
    return handler


# --------------------------------------------------------------------------
# the session
# --------------------------------------------------------------------------

@cl.on_chat_start
async def start() -> None:
    await cl.Message(content=WELCOME, author="SDLE").send()

    try:
        target = find_target()
    except SystemExit as exc:
        await cl.Message(content=f"**Not set up.**\n\n```\n{exc}\n```").send()
        return

    wf = Workflow(target, _step, None, _note_sync)
    wf.on_gate = _gate_handler(wf)
    cl.user_session.set("wf", wf)

    documents = wf.requirement_documents()
    if not documents:
        await cl.Message(
            content=f"No documents under `requirements/` in `{target}`.").send()
        return

    name = (await cl.AskUserMessage(
        content="**What is this work called?**", timeout=3600).send()
        or {}).get("output", "").strip()
    if not name:
        await cl.Message(content="No name given. Reload to start again.").send()
        return

    # The USER picks. The adapter never chooses the binding — an unbound
    # document governs nothing, so choosing for them silently drops or imports
    # constraints.
    picked = await cl.AskActionMessage(
        content="**Which requirements is this work about?**",
        actions=[cl.Action(name=d, payload={"doc": d}, label=d)
                 for d in documents],
        timeout=3600,
    ).send()
    if not picked:
        await cl.Message(content="Nothing chosen. Reload to start again.").send()
        return

    try:
        await _run(wf, name, [picked["payload"]["doc"]])
    except EngineError as exc:
        await _halt(exc)
    except TimeoutError as exc:
        await cl.Message(content=f"**Stopped.** {exc}").send()


async def _run(wf: Workflow, name: str, sources: list[str]) -> None:
    # Off the event loop: every engine call is a blocking subprocess.
    bootstrap = cl.make_async(wf.bootstrap)
    gated = cl.make_async(wf.run_gated_phase)

    data = await bootstrap(name, sources)
    await _panels(wf, f"**{data['project_name']}** initialised — "
                      f"bound to **{wf.progress()['flow']}**.")

    for phase, gate_key in (("constitution_draft", "gate_constitution"),
                            ("spec_draft", "gate_spec")):
        await gated(phase, gate_key)

    p = wf.progress()
    await _panels(wf, "### Both gates cleared")
    await cl.Message(
        content=(f"Now at **Phase {p['progress']} — {p['label']}**, where this "
                 f"proof of concept stops.\n\n"
                 f"The audit chain is real. In `{wf.target.name}`:\n"
                 f"```\npython scripts/sdle.py audit verify\n```\n"
                 f"It reports `chain_ok: true` — including your rejection, if "
                 f"you made one."),
        author="SDLE").send()


async def _halt(exc: EngineError) -> None:
    """A refusal is final. Show it and stop — never retry, never work around."""
    await cl.Message(
        content=(f"### Halted — {exc.kind}\n\n"
                 f"**`{exc.reason}`**\n\n{exc.message}\n\n"
                 + ("_A refusal means a precondition failed. The workflow has "
                    "not advanced and nothing was written._"
                    if exc.is_refusal else
                    "_Integrity failures are not repaired by hand. Stop and "
                    "read._")),
        author="SDLE").send()
