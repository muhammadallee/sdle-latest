# SDLE × Chainlit — proof of concept

Bootstrap → **Gate 1** (Constitution) → **Gate 2** (Specification). Stops there.

Enough to show the idea: a governed workflow driven from a web page, progress visible, machinery hidden, gates decided by a human — with a **real audit chain** at the end.

---

## Run it

```bash
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt     # Windows
python setup_demo.py                              # creates ./demo-target
.venv\Scripts\chainlit run app.py -w
```

Open http://localhost:8000. Name the work, pick a requirements document, read the constitution, **reject it** to see the loop, then approve.

To drive your own project instead: `set SDLE_TARGET=C:\path\to\project`.

### Without a browser

```bash
python workflow.py                              # approve everything
set POC_DECIDE=reject,approve,approve
python workflow.py                              # exercise the reject loop
```

The headless driver is how this was built and how it should be debugged. It prints what the UI would show. **Change `workflow.py`, verify here, then look at the browser** — not the other way round.

---

## What is real, and what is faked

Be straight about this in any demo.

| | |
|---|---|
| **Real** | The engine. Every state transition, gate decision, refusal, fingerprint and audit entry is `sdle.py` doing its actual job. |
| **Real** | The command sequence, including the parts that are easy to get wrong — `artifact review` before approval, `feature resolve` before Gate 2, `gate approve` advancing on its own. |
| **Faked** | **Artifact generation.** `generator.py` writes canned markdown. SDLE's own test suite simulates generation the same way; the engine cannot tell. |
| **Faked** | **The governance assessment.** `workflow._assess()` answers all twelve quality checks PASS. A real run has the model read the document and answer honestly. |
| **Stub** | **Spec Kit.** `setup_demo.py` writes a placeholder skill so `preflight` can verify discovery. Spec Kit is never invoked, because generation is stubbed. |

A stubbed constitution presented as a generated one is a lie. Say which stage you are showing.

**To make it real:** replace `generate()` in `generator.py` with a Claude Agent SDK call loaded with the target's `.claude/skills/sdle/`. The signature does not change — that is why it is behind one function.

---

## The test that actually matters

Not "does it look nice". After a run:

```bash
cd demo-target
python scripts/sdle.py audit verify
```

```
chain_ok: True   entries: 16
```

A verified hash chain containing `flow_selected`, `artifact_reviewed`, `gate_rejected`, `gate_approved` means the UI **drove the product** rather than imitating it. Observed on a run with one rejection.

---

## Layout

| File | Job |
|---|---|
| `engine.py` | Subprocess wrapper. Parses JSON, raises `EngineError` on non-zero. Never writes state. |
| `workflow.py` | The command sequence. No UI. Runnable headless. |
| `generator.py` | The stub. The only dishonest file, and it says so. |
| `app.py` | Chainlit. Collapsed steps, gate cards, progress line. |
| `setup_demo.py` | Builds `./demo-target` from the sdle-template payload. |

The UI supplies three callbacks — `on_step`, `on_gate`, `on_note` — and owns nothing else. That split is why the sequence can be verified without a browser.

---

## Three rules the adapter follows

1. **Never write `state.json` or anything under `.sdle/`.** Every mutation goes through the engine (invariant 6; a write-fence hook enforces it regardless).
2. **Never hardcode a phase or gate number.** They are flow-relative — `Gate 1/8` under GREENFIELD is a different number under HOTFIX. Always `gate show` / `resume`.
3. **A refusal (exit 1) is final.** Rendered as a halt, never retried, never routed around.

And one that is not about correctness but about the product:

> **No auto-approve, not even behind a flag.** The engine cannot tell whether a human or a model typed `approve` — that is convention, not enforcement (ADR-007 §3). A timeout here raises rather than defaulting, because a silent auto-approve would delete the only guarantee SDLE has.

---

## Four things this got wrong first, kept as comments

Each cost minutes headless; each would have cost an hour through a browser.

| Mistake | Reality |
|---|---|
| Approve from the generation phase | `not_at_gate` — you must `advance` **into** the gate first |
| Advance after approving | `gate approve` **already advances**; the extra step silently skipped `spec_draft` |
| `gate reject --comments` | It is `--reason`. Approve and reject do not share the flag |
| Expecting `gate show` to give the spec path | `None` until `feature resolve` adopts the feature directory |

Plus one platform trap: `shutil.rmtree` fails on git's read-only pack files on Windows, and with `ignore_errors=True` it fails *silently* — `setup_demo.py` clears the read-only bit instead.

---

## What this proves nothing about

- **Long-run UX.** Two phases take a minute; nineteen take hours with clarifications and drift. Reconnect, resume and session handling are the real problem and are untouched.
- **Generation quality.** Stubbed.
- **Concurrency.** One WorkItem, one tab.

Decide after looking at it, not before.
