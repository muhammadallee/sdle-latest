import { useState } from "react";

// Flow chart / code view. Every value comes from the engine via props —
// phases, gate numbers and progress are flow-relative and are never computed
// here. Dimmed nodes are real phases this PoC does not drive.

const TONE = {
  done:    { dot: "#10b981", ring: "rgba(16,185,129,.25)", text: "#d1fae5" },
  current: { dot: "#f59e0b", ring: "rgba(245,158,11,.30)", text: "#fef3c7" },
  pending: { dot: "#475569", ring: "transparent",          text: "#94a3b8" },
};

function Node({ node, last }) {
  const tone = TONE[node.state] || TONE.pending;
  const isGate = node.gate !== null && node.gate !== undefined;
  const dim = node.in_poc ? 1 : 0.38;

  return (
    <div style={{ display: "flex", gap: 14, opacity: dim }}>
      {/* rail */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 26 }}>
        <div
          style={{
            width: isGate ? 18 : 12,
            height: isGate ? 18 : 12,
            borderRadius: isGate ? 4 : 999,
            transform: isGate ? "rotate(45deg)" : "none",
            background: tone.dot,
            boxShadow: node.state === "current" ? `0 0 0 6px ${tone.ring}` : "none",
            transition: "all .25s ease",
            flexShrink: 0,
          }}
        />
        {!last && (
          <div style={{
            width: 2, flex: 1, minHeight: 22,
            background: node.state === "done" ? "#10b981" : "#334155",
            opacity: node.state === "done" ? 0.5 : 1,
          }} />
        )}
      </div>

      {/* card */}
      <div style={{ paddingBottom: 14, flex: 1 }}>
        <div style={{
          fontSize: 13.5,
          fontWeight: node.state === "current" ? 650 : 500,
          color: tone.text,
          letterSpacing: ".01em",
        }}>
          {node.label}
          {isGate && (
            <span style={{
              marginLeft: 8, fontSize: 10.5, fontWeight: 700,
              padding: "2px 7px", borderRadius: 999,
              background: "rgba(139,92,246,.18)", color: "#c4b5fd",
              border: "1px solid rgba(139,92,246,.35)",
            }}>
              GATE {node.gate}
            </span>
          )}
          {node.state === "current" && (
            <span style={{ marginLeft: 8, fontSize: 10.5, color: "#fbbf24" }}>
              ● running
            </span>
          )}
        </div>
        <div style={{ fontSize: 11, color: "#64748b", marginTop: 2, fontFamily: "ui-monospace, monospace" }}>
          {node.id}
        </div>
      </div>
    </div>
  );
}

function CodeView({ calls }) {
  return (
    <div style={{
      fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
      fontSize: 11.5, lineHeight: 1.75, color: "#94a3b8",
      maxHeight: 460, overflowY: "auto",
    }}>
      {calls.length === 0 && <div style={{ color: "#64748b" }}>No engine calls yet.</div>}
      {calls.map((c, i) => {
        const ok = c.exit === 0;
        return (
          <div key={i} style={{ display: "flex", gap: 10, padding: "1px 0" }}>
            <span style={{ color: ok ? "#10b981" : "#f87171", width: 16, flexShrink: 0 }}>
              {ok ? "✓" : "✗"}
            </span>
            <span style={{ color: "#64748b", flexShrink: 0 }}>sdle</span>
            <span style={{ color: ok ? "#e2e8f0" : "#fca5a5" }}>
              {c.args.join(" ")}
            </span>
            {!ok && c.reason && (
              <span style={{ color: "#f87171", marginLeft: "auto" }}>{c.reason}</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function FlowChart() {
  const [view, setView] = useState("flow");
  const nodes = props.nodes || [];
  const calls = props.calls || [];

  const tab = (id, label, count) => (
    <button
      onClick={() => setView(id)}
      style={{
        border: "none", cursor: "pointer",
        padding: "5px 13px", borderRadius: 7, fontSize: 12, fontWeight: 600,
        background: view === id ? "rgba(148,163,184,.16)" : "transparent",
        color: view === id ? "#e2e8f0" : "#64748b",
        transition: "all .15s",
      }}
    >
      {label}
      {count !== undefined && (
        <span style={{ marginLeft: 6, opacity: 0.6, fontWeight: 400 }}>{count}</span>
      )}
    </button>
  );

  return (
    <div style={{
      background: "linear-gradient(180deg,#0f172a 0%,#111c34 100%)",
      border: "1px solid rgba(148,163,184,.14)",
      borderRadius: 14, padding: "16px 18px",
      fontFamily: "ui-sans-serif, system-ui, -apple-system, sans-serif",
    }}>
      {/* header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "#f1f5f9", letterSpacing: "-.01em" }}>
            {props.flow}
          </div>
          <div style={{ fontSize: 11.5, color: "#64748b", marginTop: 1 }}>
            Phase {props.progress} · {props.gateTotal} gates
          </div>
        </div>
        <div style={{ display: "flex", gap: 2, background: "rgba(15,23,42,.6)", padding: 3, borderRadius: 9 }}>
          {tab("flow", "Flow")}
          {tab("code", "Engine", calls.length)}
        </div>
      </div>

      {view === "flow" ? (
        <div style={{ maxHeight: 460, overflowY: "auto", paddingRight: 4 }}>
          {nodes.map((n, i) => (
            <Node key={n.id} node={n} last={i === nodes.length - 1} />
          ))}
          <div style={{
            marginTop: 6, paddingTop: 10, fontSize: 10.5, color: "#475569",
            borderTop: "1px solid rgba(148,163,184,.10)",
          }}>
            Dimmed phases are real and governed — this proof of concept stops after Gate 2.
          </div>
        </div>
      ) : (
        <CodeView calls={calls} />
      )}
    </div>
  );
}
