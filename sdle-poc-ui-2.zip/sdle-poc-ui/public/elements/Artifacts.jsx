import { useState } from "react";

// The artifacts this run has produced. Click one to read it in a modal —
// the same content the gate showed, available again afterwards.

function Modal({ item, onClose }) {
  if (!item) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 9999,
        background: "rgba(2,6,23,.72)", backdropFilter: "blur(3px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(880px,100%)", maxHeight: "86vh", display: "flex", flexDirection: "column",
          background: "#0f172a", border: "1px solid rgba(148,163,184,.18)",
          borderRadius: 14, boxShadow: "0 24px 70px rgba(0,0,0,.6)",
        }}
      >
        <div style={{
          display: "flex", alignItems: "center", gap: 12,
          padding: "14px 18px", borderBottom: "1px solid rgba(148,163,184,.12)",
        }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14.5, fontWeight: 700, color: "#f1f5f9" }}>
              {item.title}
            </div>
            <div style={{
              fontSize: 11, color: "#64748b", marginTop: 2,
              fontFamily: "ui-monospace, monospace", overflow: "hidden", textOverflow: "ellipsis",
            }}>
              {item.path}
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              border: "1px solid rgba(148,163,184,.2)", background: "transparent",
              color: "#94a3b8", borderRadius: 8, width: 30, height: 30,
              cursor: "pointer", fontSize: 15, lineHeight: 1,
            }}
          >×</button>
        </div>

        <div style={{ padding: "16px 20px", overflowY: "auto" }}>
          <pre style={{
            margin: 0, whiteSpace: "pre-wrap", wordBreak: "break-word",
            fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
            fontSize: 12.5, lineHeight: 1.7, color: "#cbd5e1",
          }}>{item.content}</pre>
        </div>

        <div style={{
          display: "flex", gap: 14, padding: "10px 18px",
          borderTop: "1px solid rgba(148,163,184,.12)",
          fontSize: 11, color: "#64748b", fontFamily: "ui-monospace, monospace",
        }}>
          <span>{item.bytes} bytes</span>
          {item.sha && <span>sha {item.sha.slice(0, 12)}…</span>}
          {item.attempt > 1 && (
            <span style={{ color: "#fbbf24" }}>attempt {item.attempt}</span>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Artifacts() {
  const [open, setOpen] = useState(null);
  const items = props.items || [];

  return (
    <div style={{
      background: "linear-gradient(180deg,#0f172a 0%,#111c34 100%)",
      border: "1px solid rgba(148,163,184,.14)",
      borderRadius: 14, padding: "14px 16px",
      fontFamily: "ui-sans-serif, system-ui, sans-serif",
    }}>
      <div style={{
        fontSize: 11, fontWeight: 700, letterSpacing: ".09em",
        color: "#64748b", textTransform: "uppercase", marginBottom: 10,
      }}>
        Artifacts · {items.length}
      </div>

      {items.length === 0 && (
        <div style={{ fontSize: 12.5, color: "#475569" }}>
          Nothing generated yet.
        </div>
      )}

      {items.map((item) => (
        <div
          key={item.path}
          onClick={() => setOpen(item)}
          style={{
            display: "flex", alignItems: "center", gap: 11,
            padding: "9px 10px", marginBottom: 5, borderRadius: 9,
            background: "rgba(148,163,184,.05)",
            border: "1px solid rgba(148,163,184,.10)",
            cursor: "pointer", transition: "background .15s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(148,163,184,.12)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(148,163,184,.05)")}
        >
          <div style={{
            width: 26, height: 26, borderRadius: 7, flexShrink: 0,
            background: "rgba(139,92,246,.16)", border: "1px solid rgba(139,92,246,.3)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 11, color: "#c4b5fd",
          }}>◆</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#e2e8f0" }}>
              {item.title}
            </div>
            <div style={{ fontSize: 10.5, color: "#64748b", marginTop: 1 }}>
              {item.gate} · {item.bytes} bytes
              {item.attempt > 1 && (
                <span style={{ color: "#fbbf24" }}> · attempt {item.attempt}</span>
              )}
            </div>
          </div>
          <div style={{ fontSize: 11, color: "#475569" }}>read →</div>
        </div>
      ))}

      <Modal item={open} onClose={() => setOpen(null)} />
    </div>
  );
}
