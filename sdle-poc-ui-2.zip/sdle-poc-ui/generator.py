"""Artifact generation — STUBBED.

This is the one place the PoC is not real. A phase like "draft the
constitution" is model judgement, not engine work; SDLE's own test suite
simulates it the same way, by writing an artifact over the size floor, and the
engine cannot tell the difference.

Everything else in this PoC drives the real engine. Keep that distinction
visible in any demo: a stubbed constitution presented as a generated one is a
lie.

To make it real, replace `generate()` with a Claude Agent SDK call loaded with
the target's `.claude/skills/sdle/`. The signature does not change.
"""
from __future__ import annotations

import time
from pathlib import Path

#: Every artifact must clear the engine's size floor (100 bytes).
SIZE_FLOOR = 100

STUB_MODE = True


def _constitution(project: str, attempt: int, feedback: str | None) -> str:
    revision = "" if attempt == 1 else f"\n> Revised after review: {feedback}\n"
    return f"""# {project} — Project Constitution
{revision}
## Purpose
The principles this project is held to. Every later artifact is checked
against this document, and changing it is a gated decision.

## Principles

### 1. Read paths never mutate
A search endpoint performs no writes, emits no events and takes no locks. A
read that changes state is the defect class this project can least afford.

### 2. Tenancy is enforced at the query, not the caller
Regional scoping is applied where data is selected. A filter applied after
retrieval is a disclosure waiting for a bug in the layer above it.

### 3. Latency budgets are contracts
p95 under 400ms is a stated requirement, not an aspiration. A change that
cannot show it still holds does not ship.

### 4. Additive by default
Existing order endpoints keep their contracts. New capability arrives beside
the old, never through it.

### 5. Every query is attributable
An access log entry names the caller for every search. Support staff querying
the database directly is the problem being solved; an unattributable API is
the same problem with better ergonomics.

## Constraints inherited from the requirements
- No index that slows inserts on the orders table.
- No new third-party service.
- Archived orders older than 24 months are out of scope.
"""


def _specification(project: str, attempt: int, feedback: str | None) -> str:
    revision = "" if attempt == 1 else f"\n> Revised after review: {feedback}\n"
    return f"""# {project} — Specification
{revision}
## Endpoint

`GET /orders/search`

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `email` | string | no | Exact match, case-insensitive |
| `from` | date | no | Inclusive. With `to`, span must be <= 90 days |
| `to` | date | no | Inclusive |
| `reference` | string | no | Partial match, minimum 3 characters |
| `page` | int | no | Defaults to 1 |

At least one of `email`, `reference` or the date range must be supplied.

## Responses

| Status | When |
|---|---|
| 200 | Matches returned, 50 per page, sorted by `created_at` descending |
| 400 | No criteria given, date span over 90 days, or reference under 3 chars |
| 403 | Caller token carries no regional scope |

## Behaviour

Regional scoping is applied in the query predicate. A caller scoped to `eu`
cannot observe `us` orders through any combination of parameters, including an
empty result count.

Pagination is stable: `created_at` descending, `id` ascending as tie-break, so
a row is neither repeated nor skipped across pages.

## Acceptance

- p95 under 400ms at 50 rps against a production-shaped dataset.
- A 91-day span returns 400 with the span named in the message.
- Cross-region probing returns the same response shape as an empty result.
- Every request appears in the access log with the caller id.
"""


_GENERATORS = {
    "constitution_draft": _constitution,
    "spec_draft": _specification,
}


def generate(phase: str, target: Path, artifact_path: str, project: str,
             attempt: int = 1, feedback: str | None = None) -> Path:
    """Write the artifact for `phase` and return its path.

    `attempt` and `feedback` exist so a rejection produces a visibly different
    document — a reject loop that regenerates the identical text proves
    nothing.
    """
    build = _GENERATORS.get(phase)
    if build is None:
        raise KeyError(f"No stub generator for phase {phase!r}")

    text = build(project, attempt, feedback)
    if len(text.encode("utf-8")) < SIZE_FLOOR:
        raise ValueError("stub artifact is under the engine's size floor")

    out = target / artifact_path
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8", newline="\n")

    time.sleep(0.6)  # so the collapsed step is visibly doing something
    return out
