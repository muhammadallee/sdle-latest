"""Current run state, published for the fixed side panel.

Option A puts the flow and artifacts in a panel that never scrolls away. That
panel is plain DOM in `sdle-chrome.js`, mounted outside Chainlit's React root —
so it cannot receive props the way a `CustomElement` does. It polls this
instead, over a small JSON route the app registers on Chainlit's own FastAPI
instance.

One process, one run, one browser: a module-level dict is the right size for a
proof of concept. A real build would key this by Chainlit session id.
"""
from __future__ import annotations

import threading

_LOCK = threading.Lock()

_STATE: dict = {
    "active": False,
    "project": None,
    "flow": None,
    "progress": None,
    "label": None,
    "gateTotal": None,
    "nodes": [],
    "artifacts": [],
    "calls": [],
    "awaiting": None,     # the gate caption while a decision is pending
}


def publish(**fields) -> None:
    with _LOCK:
        _STATE.update(fields)


def snapshot() -> dict:
    with _LOCK:
        return dict(_STATE)


def reset() -> None:
    with _LOCK:
        _STATE.update({"active": False, "project": None, "flow": None,
                       "progress": None, "label": None, "gateTotal": None,
                       "nodes": [], "artifacts": [], "calls": [],
                       "awaiting": None})
