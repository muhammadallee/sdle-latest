"""Build a self-contained copy of this PoC for another machine.

    python make_bundle.py            ->  ../sdle-poc-bundle/  and a .zip

It takes the source that matters and leaves out everything a target machine
must build for itself (.venv, demo-target, caches, uploads). It also copies the
SDLE payload and the documentation in, so the two paths that used to point at
this machine resolve locally instead.
"""
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

HERE = Path(__file__).parent.resolve()
OUT = HERE.parent / "sdle-poc-bundle"

#: Everything the app needs to run.
FILES = ["app.py", "workflow.py", "engine.py", "generator.py",
         "docsearch.py", "state_bus.py", "setup_demo.py",
         "requirements.txt", "README.md"]
DIRS = ["public", ".chainlit"]

#: Never copied: built on the target, or machine-local.
SKIP = {".venv", "demo-target", "__pycache__", ".files", ".git",
        "sdle-v2.html", "make_bundle.py"}


def copy_tree(src: Path, dst: Path) -> int:
    n = 0
    for p in src.rglob("*"):
        if any(part in SKIP for part in p.parts):
            continue
        if p.is_file():
            rel = p.relative_to(src)
            out = dst / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, out)
            n += 1
    return n


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT, ignore_errors=True)
    OUT.mkdir(parents=True)

    n = 0
    for name in FILES:
        src = HERE / name
        if src.is_file():
            shutil.copy2(src, OUT / name)
            n += 1
    for name in DIRS:
        src = HERE / name
        if src.is_dir():
            n += copy_tree(src, OUT / name)

    # The SDLE install, so `setup_demo.py` finds a payload locally.
    payload = HERE.parent / "sdle-template" / "payload"
    if payload.is_dir():
        n += copy_tree(payload, OUT / "payload")
        print(f"  payload:  bundled from {payload}")
    else:
        print("  payload:  NOT FOUND — setup_demo.py will need SDLE_TARGET")

    # The documentation, so the Q&A resolves without SDLE_DOCS.
    from docsearch import DocIndex
    docs_root = DocIndex().root
    if (docs_root / "docs" / "SDLE-Reference-Guide.md").is_file():
        dst = OUT / "sdle-docs"
        for rel in ("README.md", "docs"):
            s = docs_root / rel
            if s.is_file():
                (dst).mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, dst / rel)
                n += 1
            elif s.is_dir():
                n += copy_tree(s, dst / rel)
        print(f"  docs:     bundled from {docs_root}")
    else:
        print("  docs:     NOT FOUND — the Q&A will need SDLE_DOCS")

    zip_path = OUT.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p, Path(OUT.name) / p.relative_to(OUT))

    size = zip_path.stat().st_size / 1_048_576
    print(f"\n{n} files -> {OUT}")
    print(f"           {zip_path}  ({size:.1f} MB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
