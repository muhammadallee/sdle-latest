"""SDLE in a Chainlit UI — proof of concept.

Run:  chainlit run app.py -w

Scope: bootstrap -> Generate Constitution -> Gate 1 -> Generate Specification
-> Gate 2. That slice contains every interaction pattern the full 19-phase
product needs; everything after it is these same patterns repeating.

The UI owns the presentation and nothing else. The command sequence lives in
workflow.py so it can be driven headless (`python workflow.py`) — which is how
it was built and how it should be debugged.

Two things here are load-bearing and easy to get wrong:

* **The workflow runs in a worker thread** (`cl.make_async`). Every engine call
  is a blocking subprocess; running them on the event loop freezes the browser
  and no step ever streams. `cl.run_sync` marshals back to the loop from the
  worker, which is what makes the gate prompt work from inside the thread.
* **Elements are inline, not `ElementSidebar`.** The sidebar renders a custom
  element's title and an empty body; inline elements render correctly.
"""
from __future__ import annotations

import contextlib

import os

import chainlit as cl

#: cl.Step across the worker-thread boundary is the suspect for the freeze;
#: this makes it switchable so the cause can be isolated rather than guessed.
_USE_STEPS = os.environ.get("POC_STEPS", "1") != "0"

import state_bus
from docsearch import excerpt, index
from engine import EngineError, find_target
from workflow import Gate, Workflow

# The fixed side panel (Option A) lives outside React and cannot take props, so
# it polls. Chainlit is FastAPI underneath; this is its own small route.
try:
    from chainlit.server import app as _fastapi

    @_fastapi.get("/sdle/state")
    async def _sdle_state():          # noqa: D401 - route, not a helper
        return state_bus.snapshot()

    @_fastapi.get("/sdle/ask")
    async def _sdle_ask(q: str = ""):
        """The documentation Q&A, for the popup.

        Its own endpoint rather than Chainlit's conversation, because the
        popup is a *separate* conversation: temporary, discarded on close, and
        never mixed into the run's thread.
        """
        return answer_from_docs(q)

    # Chainlit mounts its own router (including the single-page catch-all)
    # ahead of anything registered afterwards, so a route appended here is
    # never reached — the request returns index.html instead of JSON. Move
    # both to the front of the table.
    _fastapi.router.routes.insert(0, _fastapi.router.routes.pop())
    _fastapi.router.routes.insert(0, _fastapi.router.routes.pop())
except Exception:                      # pragma: no cover - never break the app
    pass

WELCOME = """\
## Spec Driven Lifecycle Engine

A governed delivery workflow. You name the work, choose what it is about, and
**decide at every gate** — nothing advances on its own.

The panel on the right tracks the run and stays put while you work — switch it
to **Engine** to see every command.

You can also **ask questions about SDLE** at any time. Answers come straight
from the documentation, with a reference.

*Artifact generation is stubbed in this proof of concept. The engine, the
gates and the audit chain are real.*
"""


# --------------------------------------------------------------------------
# the two panels
# --------------------------------------------------------------------------

def publish(wf: Workflow, awaiting: str | None = None) -> None:
    """Push the current run into the side panel.

    Option A's whole point: the flow does not live in the conversation, so it
    cannot scroll away. Nothing is sent as a message here.
    """
    try:
        flow = wf.flow_view()
    except EngineError:
        return                      # before `init` there is no flow to draw
    state_bus.publish(active=True, project=wf.project, flow=flow["flow"],
                      progress=flow["progress"], label=flow.get("label"),
                      gateTotal=flow["gateTotal"], nodes=flow["nodes"],
                      calls=flow["calls"], artifacts=wf.artifact_view(),
                      awaiting=awaiting)


# --------------------------------------------------------------------------
# callbacks handed to the workflow (called from the worker thread)
# --------------------------------------------------------------------------

def _step(label: str):
    """A collapsed step. The engine call happens inside; its JSON never shows.

    This is the whole "hide the logs" mechanism — SKILL.md's verbosity rules
    say to suppress script invocations, SHA computation and state-write
    narration, and always to show phase start and completion. A collapsed step
    is exactly that split, and the Engine tab is the `verbose on` escape hatch.
    """
    @contextlib.contextmanager
    def ctx():
        # `with cl.Step(...)` raises "no running event loop" here: the sync
        # context manager wants the loop, and this runs in a worker thread.
        # Drive the async form through run_sync, which marshals to the main
        # loop via run_coroutine_threadsafe.
        if _USE_STEPS:
            step = cl.Step(name=label, type="run", show_input=False)
            cl.run_sync(step.__aenter__())
            try:
                yield
            finally:
                cl.run_sync(step.__aexit__(None, None, None))
        else:
            yield
    return ctx()


def _note_sync(text: str) -> None:
    cl.run_sync(cl.Message(content=text, author="SDLE").send())


async def _gate_card(gate: Gate, text: str) -> str | tuple[str, str]:
    """The decision. Artifact shown IN FULL above the buttons.

    Invariant 4: the user never opens a file to know what they are approving.
    "Hide the logs" must never become "hide the artifact".
    """
    await cl.Message(
        content=(f"### {gate.caption} — {gate.label}\n"
                 f"`{gate.artifact_path}`\n\n---\n\n{text}"),
        author="SDLE",
    ).send()

    res = await cl.AskActionMessage(
        content="**Your decision.** Nothing advances until you choose.",
        actions=[
            cl.Action(name="approve", payload={"d": "approve"},
                      label="✓  Approve"),
            cl.Action(name="reject", payload={"d": "reject"},
                      label="✗  Reject"),
        ],
        timeout=3600,
    ).send()

    # No default. A timeout is not an approval — the engine cannot tell a human
    # from a model, so a silent auto-approve would delete the only guarantee
    # this product has (ADR-007 §3).
    if not res:
        raise TimeoutError("No decision was made.")
    if res.get("payload", {}).get("d") != "reject":
        return "approve"

    ask = await cl.AskUserMessage(
        content="What needs to change? It is recorded in the audit chain.",
        timeout=3600,
    ).send()
    reason = (ask or {}).get("output", "").strip() or "Rejected without detail."
    return ("reject", reason)


def _gate_handler(wf: Workflow):
    def handler(gate: Gate, text: str):
        publish(wf, awaiting=gate.caption)   # panel shows the artifact now
        # Deliberately NOT re-sending the panels here. An earlier version did,
        # and a rejection then queued a second 19-node element while the first
        # ask was still unwinding — the browser froze, though the engine had
        # recorded the rejection correctly. Panels are sent once per phase, in
        # `_run`. The artifact itself is in the gate card below, in full.
        return cl.run_sync(_gate_card(gate, text))
    return handler


# --------------------------------------------------------------------------
# the session
# --------------------------------------------------------------------------

@cl.on_chat_start
async def start() -> None:
    """Offer the choice; do not seize the composer.

    An earlier version started the workflow immediately, and its first act was
    `AskUserMessage` — which captures the input box. The documentation Q&A was
    then unreachable until both gates had been cleared. It was not hidden, it
    was blocked.
    """
    await cl.Message(content=WELCOME, author="SDLE").send()

    try:
        target = find_target()
    except SystemExit as exc:
        await cl.Message(content=f"**Not set up.**\n\n```\n{exc}\n```").send()
        return

    wf = Workflow(target, _step, None, _note_sync)
    wf.on_gate = _gate_handler(wf)
    cl.user_session.set("wf", wf)
    cl.user_session.set("running", False)

    ix = index()
    choice = await cl.AskActionMessage(
        content=(f"**What would you like to do?**\n\n"
                 f"You can also just type a question at any time — "
                 f"{len(ix.passages)} sections of the SDLE documentation are "
                 f"indexed."),
        actions=[
            cl.Action(name="run", payload={"a": "run"},
                      label="▶  Start a work item"),
            cl.Action(name="ask", payload={"a": "ask"},
                      label="?  Ask about SDLE"),
        ],
        timeout=3600,
    ).send()

    if not choice or choice.get("payload", {}).get("a") == "ask":
        await _docs_intro()
        return

    await _begin_run(wf)


async def _docs_intro() -> None:
    ix = index()
    if not ix.ready:
        await cl.Message(
            content=f"No documentation indexed. Set `SDLE_DOCS` to an SDLE "
                    f"checkout — currently looking in `{ix.root}`.",
            author="SDLE").send()
        return
    await cl.Message(
        content=("### Ask about SDLE\n\n"
                 f"**{len(ix.passages)} sections** indexed from the reference "
                 "guide, the ADRs, the tutorials and the troubleshooting "
                 "guide. Answers are **retrieved, not generated** — you get the "
                 "documentation's own words, with the file and section they "
                 "came from.\n\n"
                 "Try:\n"
                 "- *What happens if I reject a gate?*\n"
                 "- *Why are requirements at the repository root?*\n"
                 "- *What is the difference between DEFECT_FIX and HOTFIX?*\n"
                 "- *What does `governance_stale` mean?*\n\n"
                 "Say **start** whenever you want to begin a work item."),
        author="SDLE").send()


async def _begin_run(wf: Workflow) -> None:
    documents = wf.requirement_documents()
    if not documents:
        await cl.Message(
            content=f"No documents under `requirements/` in `{wf.target}`."
        ).send()
        return

    cl.user_session.set("running", True)
    try:
        name = (await cl.AskUserMessage(
            content="**What is this work called?**", timeout=3600).send()
            or {}).get("output", "").strip()
        if not name:
            await cl.Message(content="No name given. Say **start** to try "
                                     "again.").send()
            return

        # The USER picks. The adapter never chooses the binding — an unbound
        # document governs nothing, so choosing for them silently drops or
        # imports constraints.
        picked = await cl.AskActionMessage(
            content="**Which requirements is this work about?**",
            actions=[cl.Action(name=d, payload={"doc": d}, label=d)
                     for d in documents],
            timeout=3600,
        ).send()
        if not picked:
            await cl.Message(content="Nothing chosen. Say **start** to try "
                                     "again.").send()
            return

        await _run(wf, name, [picked["payload"]["doc"]])
    except EngineError as exc:
        await _halt(exc)
    except TimeoutError as exc:
        await cl.Message(content=f"**Stopped.** {exc}").send()
    finally:
        cl.user_session.set("running", False)


async def _run(wf: Workflow, name: str, sources: list[str]) -> None:
    # Off the event loop: every engine call is a blocking subprocess.
    bootstrap = cl.make_async(wf.bootstrap)
    gated = cl.make_async(wf.run_gated_phase)

    data = await bootstrap(name, sources)
    publish(wf)
    await cl.Message(
        content=f"**{data['project_name']}** is initialised and bound to "
                f"**{wf.progress()['flow']}**. The panel on the right tracks "
                f"every phase — it stays put while you work.",
        author="SDLE").send()

    for phase, gate_key in (("constitution_draft", "gate_constitution"),
                            ("spec_draft", "gate_spec")):
        await gated(phase, gate_key)
        publish(wf)

    p = wf.progress()
    publish(wf)
    await cl.Message(
        content=(f"Now at **Phase {p['progress']} — {p['label']}**, where this "
                 f"proof of concept stops.\n\n"
                 f"The audit chain is real. In `{wf.target.name}`:\n"
                 f"```\npython scripts/sdle.py audit verify\n```\n"
                 f"It reports `chain_ok: true` — including your rejection, if "
                 f"you made one."),
        author="SDLE").send()


async def _halt(exc: EngineError) -> None:
    """A refusal is final. Show it and stop — never retry, never work around."""
    await cl.Message(
        content=(f"### Halted — {exc.kind}\n\n"
                 f"**`{exc.reason}`**\n\n{exc.message}\n\n"
                 + ("_A refusal means a precondition failed. The workflow has "
                    "not advanced and nothing was written._"
                    if exc.is_refusal else
                    "_Integrity failures are not repaired by hand. Stop and "
                    "read._")),
        author="SDLE").send()


# --------------------------------------------------------------------------
# Ask the documentation
# --------------------------------------------------------------------------

NO_ANSWER = """I could not find that in the SDLE documentation.

This answers **only** from the shipped docs — the reference guide, the ADRs,
the tutorials and the troubleshooting guide. It retrieves what is written
there; it does not compose an answer of its own, so if the docs are silent, so
am I."""


@cl.on_message
async def on_message(message: cl.Message) -> None:
    """Typed input outside a step: `start`, or a documentation question.

    The workflow's own prompts use `AskUserMessage` / `AskActionMessage`, which
    take precedence — so this only ever sees messages typed between steps.
    """
    question = (message.content or "").strip()
    if not question:
        return

    if question.lower() in {"start", "start workflow", "begin", "new",
                            "run", "start a work item"}:
        wf = cl.user_session.get("wf")
        if wf is None:
            await cl.Message(content="Reload the page to start.").send()
        else:
            await _begin_run(wf)
        return

    result = answer_from_docs(question)
    await cl.Message(content=result["markdown"], author="SDLE").send()


def answer_from_docs(question: str) -> dict:
    """Retrieval, not generation — shared by the popup and the main chat.

    The reply is prose somebody wrote in the documentation set, quoted, with
    the file and section it came from. A governance engine is exactly the wrong
    thing to be confidently wrong about, and this proof of concept has no model
    wired in to be right with.
    """
    question = (question or "").strip()
    if not question:
        return {"ok": False, "markdown": "Ask a question.", "references": []}

    ix = index()
    if not ix.ready:
        msg = (f"No documentation indexed. Set `SDLE_DOCS` to an SDLE "
               f"checkout — currently looking in `{ix.root}`.")
        return {"ok": False, "markdown": msg, "references": []}

    hits = ix.search(question, top=3)
    if not hits:
        return {"ok": False, "markdown": NO_ANSWER, "references": []}

    top, score = hits[0]
    body = excerpt(top.body, question)

    quoted = "\n".join(f"> {ln}" if ln.strip() else ">"
                        for ln in body.splitlines())
    out = [f"**{top.title}**", "", quoted, "", f"— `{top.path}`"]

    others = [h for h in hits[1:] if h[1] > score * 0.45]
    if others:
        out += ["", "**Also relevant**"]
        out += [f"- `{p.path}` · {p.title}" for p, _ in others]

    out += ["", "*Retrieved from the documentation, not generated.*"]

    return {
        "ok": True,
        "title": top.title,
        "body": body,
        "markdown": "\n".join(out),
        "references": [{"path": p.path, "title": p.title}
                       for p, _ in hits],
    }
