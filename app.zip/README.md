# SDLE × Chainlit — proof of concept

Bootstrap → **Gate 1** (Constitution) → **Gate 2** (Specification). Stops there.

Enough to show the idea: a governed workflow driven from a web page, progress visible, machinery hidden, gates decided by a human — with a **real audit chain** at the end.

---

## Run it

```bash
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt     # Windows
python setup_demo.py                              # creates ./demo-target
.venv\Scripts\chainlit run app.py -w
```

Open http://localhost:8000. Name the work, pick a requirements document, read the constitution, **reject it** to see the loop, then approve.

To drive your own project instead: `set SDLE_TARGET=C:\path\to\project`.

### Without a browser

```bash
python workflow.py                              # approve everything
set POC_DECIDE=reject,approve,approve
python workflow.py                              # exercise the reject loop
```

The headless driver is how this was built and how it should be debugged. It prints what the UI would show. **Change `workflow.py`, verify here, then look at the browser** — not the other way round.

---

## What is real, and what is faked

Be straight about this in any demo.

| | |
|---|---|
| **Real** | The engine. Every state transition, gate decision, refusal, fingerprint and audit entry is `sdle.py` doing its actual job. |
| **Real** | The command sequence, including the parts that are easy to get wrong — `artifact review` before approval, `feature resolve` before Gate 2, `gate approve` advancing on its own. |
| **Faked** | **Artifact generation.** `generator.py` writes canned markdown. SDLE's own test suite simulates generation the same way; the engine cannot tell. |
| **Faked** | **The governance assessment.** `workflow._assess()` answers all twelve quality checks PASS. A real run has the model read the document and answer honestly. |
| **Stub** | **Spec Kit.** `setup_demo.py` writes a placeholder skill so `preflight` can verify discovery. Spec Kit is never invoked, because generation is stubbed. |

A stubbed constitution presented as a generated one is a lie. Say which stage you are showing.

**To make it real:** replace `generate()` in `generator.py` with a Claude Agent SDK call loaded with the target's `.claude/skills/sdle/`. The signature does not change — that is why it is behind one function.

---

## Layout: the flow does not live in the conversation

The run panel is fixed to the right and shows **Flow · Artifacts · Engine**. It
never scrolls away, which was the whole complaint about the first version.

It sits outside React, so it cannot take props — it polls `/sdle/state`, a route
the app registers on Chainlit's own FastAPI instance. One catch worth knowing:
Chainlit mounts its single-page catch-all *before* anything registered
afterwards, so the route has to be moved to the front of the table or every
request returns `index.html` instead of JSON.

The conversation now carries only what needs a person: prompts, gate cards and
decisions.

## Work items: Active and Completed

The rail has two tabs with counts — **Active (2)** and **Completed (3)** —
holding sample rows. Opening one returns to the initial conversation state.

That is a reload, deliberately: this proof of concept has **no persistence**,
so there is no thread to restore. Faking a transcript would misrepresent what
the product does, and the rail's own footnote says so.

## Ask the documentation

**Header button → its own popup.** Each click opens a *fresh* conversation:
temporary, never mixed into the run's thread, and discarded on close. It talks
to `/sdle/ask` directly rather than to Chainlit, which is what keeps the two
apart.

You can also type a question into the main composer when no step is waiting:

> What happens if I reject a gate?

The reply is **retrieved, not generated** — a BM25 index over the shipped docs
(reference guide, ADRs, tutorials, troubleshooting) returns the actual prose
with the file and section it came from. There is no model wired in, and a
governance engine is the wrong thing to be confidently wrong about.

Sections that are mostly a fenced diagram or a table are ranked lower: 8.1
"Phase & Gate Flow" is a mermaid block and was beating the prose that actually
explains rejection.

Point it elsewhere with `SDLE_DOCS=<an SDLE checkout>`.

## Known issue — read this before demoing

**The browser can freeze partway through a live run.** The server is fine when it
happens: the engine records everything correctly and the audit chain still
verifies. It is a client-side rendering problem, not a workflow one.

Verified individually in a browser, all working:

| | |
|---|---|
| Flow chart, 19 nodes, live states | ✅ |
| Flow ↔ Engine toggle | ✅ |
| Artifact list and modal | ✅ |
| Gate card with full artifact + Approve/Reject | ✅ |
| Reject → reason → recorded as `gate_rejected` | ✅ (confirmed in the audit chain) |

The **full unattended run** is flaky. Prime suspect is `cl.Step` driven across
the `cl.make_async` worker-thread boundary — every step enter and exit is a
`run_coroutine_threadsafe` round-trip. Set `POC_STEPS=0` to disable steps and
isolate it:

```bash
set POC_STEPS=0
chainlit run app.py -w
```

If that runs clean, the steps are the cause and the fix is to emit progress as
plain messages from the loop rather than as nested steps from the worker.

**`python workflow.py` is unaffected and always works.** Demo from there if the
browser misbehaves — it prints the same sequence.

## The test that actually matters

Not "does it look nice". After a run:

```bash
cd demo-target
python scripts/sdle.py audit verify
```

```
chain_ok: True   entries: 16
```

A verified hash chain containing `flow_selected`, `artifact_reviewed`, `gate_rejected`, `gate_approved` means the UI **drove the product** rather than imitating it. Observed on a run with one rejection.

---

## Layout

| File | Job |
|---|---|
| `engine.py` | Subprocess wrapper. Parses JSON, raises `EngineError` on non-zero. Never writes state. |
| `workflow.py` | The command sequence. No UI. Runnable headless. |
| `generator.py` | The stub. The only dishonest file, and it says so. |
| `app.py` | Chainlit. Steps, gate cards, panels. |
| `public/elements/FlowChart.jsx` | Flow chart + Engine (code) view toggle. |
| `public/elements/Artifacts.jsx` | Artifact list; click opens a modal. |
| `public/sdle-chrome.js` | Header, work-item rail, **fixed run panel**, footer, content sections. |
| `docsearch.py` | BM25 index over the SDLE docs — answers questions by retrieval. |
| `state_bus.py` | Current run state, published to the panel over `/sdle/state`. |
| `public/pages.json` | Business value / How it works / Governance, lifted from `sdle-v2.html`. |
| `public/theme.json`, `public/style.css` | Navy/gold theme from `sdle-v2.html`. |
| `public/brand-logo.svg`, `public/avatars/sdle.svg` | Brand mark and assistant avatar. |
| `setup_demo.py` | Builds `./demo-target` from the sdle-template payload. |

The UI supplies three callbacks — `on_step`, `on_gate`, `on_note` — and owns nothing else. That split is why the sequence can be verified without a browser.

---

## Three rules the adapter follows

1. **Never write `state.json` or anything under `.sdle/`.** Every mutation goes through the engine (invariant 6; a write-fence hook enforces it regardless).
2. **Never hardcode a phase or gate number.** They are flow-relative — `Gate 1/8` under GREENFIELD is a different number under HOTFIX. Always `gate show` / `resume`.
3. **A refusal (exit 1) is final.** Rendered as a halt, never retried, never routed around.

And one that is not about correctness but about the product:

> **No auto-approve, not even behind a flag.** The engine cannot tell whether a human or a model typed `approve` — that is convention, not enforcement (ADR-007 §3). A timeout here raises rather than defaulting, because a silent auto-approve would delete the only guarantee SDLE has.

---

## Four things this got wrong first, kept as comments

Each cost minutes headless; each would have cost an hour through a browser.

| Mistake | Reality |
|---|---|
| `ElementSidebar` for the panels | Renders the element title and an empty body. Inline elements work |
| `with cl.Step(...)` from the worker thread | "no running event loop" — drive `__aenter__`/`__aexit__` through `run_sync` |
| Blocking engine calls on the event loop | Froze the browser and streamed nothing. `cl.make_async` puts them in a thread |
| Padding `#root` to make room for fixed chrome | Chainlit sizes its shell with `h-screen`/`min-h-svh`; every ancestor needs a *definite* height or the composer overflows under the footer |
| Styling Approve/Reject by `data-testid` | They have none, and their ids are random UUIDs. `sdle-chrome.js` tags them by label instead |
| Approve from the generation phase | `not_at_gate` — you must `advance` **into** the gate first |
| Advance after approving | `gate approve` **already advances**; the extra step silently skipped `spec_draft` |
| `gate reject --comments` | It is `--reason`. Approve and reject do not share the flag |
| Expecting `gate show` to give the spec path | `None` until `feature resolve` adopts the feature directory |

Plus one platform trap: `shutil.rmtree` fails on git's read-only pack files on Windows, and with `ignore_errors=True` it fails *silently* — `setup_demo.py` clears the read-only bit instead.

---

## What this proves nothing about

- **Long-run UX.** Two phases take a minute; nineteen take hours with clarifications and drift. Reconnect, resume and session handling are the real problem and are untouched.
- **Generation quality.** Stubbed.
- **Concurrency.** One WorkItem, one tab.

Decide after looking at it, not before.
