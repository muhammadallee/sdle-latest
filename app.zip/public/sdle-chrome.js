/* SDLE chrome — header, work-item rail, fixed run panel, footer, sections.
 *
 * All of this is appended to <body> as siblings of Chainlit's React root, not
 * injected into it: React owns #root and re-renders freely, so anything placed
 * inside would be wiped.
 *
 * The run panel (Option A) is the point of the layout: flow, artifacts and
 * engine calls live here permanently instead of in the conversation, so they
 * cannot scroll away. It sits outside React and therefore cannot receive props
 * — it polls /sdle/state, a small route the app registers on Chainlit's own
 * FastAPI instance.
 *
 * Look and feel follows sdle-v2.html.
 */
(function () {
  "use strict";

  var NAV = [
    { label: "Overview", route: "" },
    { label: "Business value", route: "value" },
    { label: "How it works", route: "how" },
    { label: "Governance", route: "governance" }
  ];

  // Stand-ins. Real threads need a Chainlit data layer; this PoC keeps none,
  // and the rail says so in its own footnote rather than implying otherwise.
  var WORK_ITEMS = {
    active: [
      { title: "Order search API", meta: "GREENFIELD · Gate 2 of 8" },
      { title: "Low stock alerts", meta: "ITERATIVE · Gate 5 of 7" }
    ],
    completed: [
      { title: "Refund reversal defect", meta: "DEFECT_FIX · 8 gates cleared" },
      { title: "Warehouse scoping hotfix", meta: "HOTFIX · 3 gates cleared" },
      { title: "Reporting export", meta: "BROWNFIELD · 8 gates cleared" }
    ]
  };

  var panelTab = "flow";
  var lastState = null;

  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  /* ----------------------------------------------------------- header */

  function buildHeader(logoSvg) {
    var header = el("header", "sdle-header");
    var inner = el("div", "sdle-header-inner");

    var brand = el("a", "sdle-brand");
    brand.href = "#";
    brand.setAttribute("aria-label", "SDLE home");
    brand.appendChild(el("span", "sdle-brand-logo", logoSvg));
    brand.appendChild(el("span", "sdle-brand-text", "<strong>SDLE</strong>"));
    brand.addEventListener("click", function (e) {
      e.preventDefault();
      showRoute("");
      selectNav(0);
    });

    var nav = el("nav", "sdle-nav");
    nav.setAttribute("aria-label", "Main navigation");
    NAV.forEach(function (item, i) {
      var a = el("a", i === 0 ? "selected" : "", item.label);
      a.href = "#" + item.route;
      a.addEventListener("click", function (e) {
        e.preventDefault();
        showRoute(item.route);
        selectNav(i);
      });
      nav.appendChild(a);
    });

    var end = el("div", "sdle-header-end");

    var askBtn = el("button", "sdle-ask-btn", "Ask about SDLE");
    askBtn.type = "button";
    askBtn.title = "Ask the documentation — opens a separate conversation";
    askBtn.addEventListener("click", openAsk);
    end.appendChild(askBtn);

    var theme = el("button", "sdle-icon-button", "◐");
    theme.type = "button";
    theme.title = "Toggle theme";
    theme.setAttribute("aria-label", "Toggle theme");
    theme.addEventListener("click", function () {
      var next = document.documentElement.classList.contains("dark")
        ? "light" : "dark";
      try { localStorage.setItem("themeVariant", next); } catch (e) {}
      document.documentElement.classList.toggle("dark", next === "dark");
    });
    end.appendChild(theme);

    inner.appendChild(brand);
    inner.appendChild(nav);
    inner.appendChild(end);
    header.appendChild(inner);
    return header;
  }

  function selectNav(idx) {
    var links = document.querySelectorAll(".sdle-nav a");
    for (var i = 0; i < links.length; i++) {
      links[i].classList.toggle("selected", i === idx);
    }
  }

  /* ------------------------------------------------------- left rail */

  var railTab = "active";

  function buildRail() {
    var rail = el("aside", "sdle-rail");
    rail.setAttribute("aria-label", "Work items");
    rail.appendChild(el("div", "sdle-rail-head", "<span>Work items</span>"));

    var newBtn = el("button", "sdle-rail-new", "+ New");
    newBtn.type = "button";
    newBtn.title = "Start a new work item";
    newBtn.addEventListener("click", function () { window.location.reload(); });
    rail.querySelector(".sdle-rail-head").appendChild(newBtn);

    rail.appendChild(el("div", "sdle-rail-tabs"));
    rail.appendChild(el("div", "sdle-rail-list"));
    rail.appendChild(el("div", "sdle-rail-foot",
      "Sample history — this proof of concept keeps no threads, so " +
      "opening one returns to the start."));
    renderRail(rail);
    return rail;
  }

  function renderRail(rail) {
    rail = rail || document.querySelector(".sdle-rail");
    if (!rail) return;

    var tabs = rail.querySelector(".sdle-rail-tabs");
    tabs.innerHTML = "";
    [["active", "Active"], ["completed", "Completed"]].forEach(function (pair) {
      var key = pair[0];
      var b = el("button", "sdle-rail-tab" + (railTab === key ? " on" : ""),
        pair[1] + ' <em>' + WORK_ITEMS[key].length + "</em>");
      b.type = "button";
      b.addEventListener("click", function () {
        railTab = key;
        renderRail();
      });
      tabs.appendChild(b);
    });

    var list = rail.querySelector(".sdle-rail-list");
    list.innerHTML = "";
    WORK_ITEMS[railTab].forEach(function (c) {
      var item = el("button", "sdle-conv" + (railTab === "completed"
        ? " done" : ""));
      item.type = "button";
      item.innerHTML =
        '<span class="sdle-conv-title">' + esc(c.title) + "</span>" +
        '<span class="sdle-conv-meta">' + c.meta + "</span>";
      item.addEventListener("click", function () { openWorkItem(c); });
      list.appendChild(item);
    });
  }

  /* Opening a work item returns to the initial conversation state.
     There is no persistence in this proof of concept — no thread to restore —
     so a reload is the honest equivalent rather than a faked transcript. */
  function openWorkItem(c) {
    window.location.reload();
  }

  /* ------------------------------------------------ ask popup (separate)
   * A conversation of its own: opened fresh every time, never mixed into the
   * run's thread, and discarded when closed. It talks to /sdle/ask directly
   * rather than to Chainlit, which is what keeps the two apart.
   */
  function openAsk() {
    var existing = document.querySelector(".sdle-askwin-back");
    if (existing) existing.remove();          // fresh conversation each time

    var back = el("div", "sdle-askwin-back");
    var win = el("div", "sdle-askwin");
    win.innerHTML =
      '<div class="sdle-askwin-head">' +
        "<div><b>Ask about SDLE</b><small>Answers come from the " +
        "documentation, with a reference</small></div>" +
      "</div>" +
      '<div class="sdle-askwin-body"></div>' +
      '<div class="sdle-askwin-foot">' +
        '<input class="sdle-askwin-in" type="text" ' +
        'placeholder="Ask a question…" autocomplete="off">' +
        '<button class="sdle-askwin-send" type="button">Ask</button>' +
      "</div>";

    var x = el("button", "sdle-modal-x", "×");
    x.type = "button";
    win.querySelector(".sdle-askwin-head").appendChild(x);
    back.appendChild(win);
    document.body.appendChild(back);

    var body = win.querySelector(".sdle-askwin-body");
    var input = win.querySelector(".sdle-askwin-in");

    function close() { back.remove(); }
    x.addEventListener("click", close);
    back.addEventListener("click", function (e) {
      if (e.target === back) close();
    });
    document.addEventListener("keydown", function esc0(e) {
      if (e.key === "Escape" && document.body.contains(back)) {
        close();
        document.removeEventListener("keydown", esc0);
      }
    });

    function bubble(cls, html) {
      var b = el("div", "sdle-bub " + cls, html);
      body.appendChild(b);
      body.scrollTop = body.scrollHeight;
      return b;
    }

    function send(q) {
      q = (q || input.value).trim();
      if (!q) return;
      input.value = "";
      bubble("me", esc(q));
      var wait = bubble("them", "<i>Searching the documentation…</i>");
      fetch("/sdle/ask?q=" + encodeURIComponent(q))
        .then(function (r) { return r.json(); })
        .catch(function () { return null; })
        .then(function (d) {
          wait.remove();
          if (!d) { bubble("them", "Could not reach the server."); return; }
          bubble("them", render(d));
        });
    }

    /* Just enough Markdown for a quoted passage: bold, inline code and
       bullets. Not a parser — the text is escaped first, so nothing in the
       documentation can inject markup here. */
    function lite(s) {
      var out = esc(s);
      out = out.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
      out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
      out = out.replace(/^- /gm, "• ");
      // An excerpt can cut mid-sentence and leave an unclosed marker behind.
      out = out.replace(/\*\*/g, "");
      return out;
    }

    function render(d) {
      if (!d.ok) return esc(d.markdown || "No answer.");
      var refs = (d.references || []).map(function (r) {
        return '<span class="sdle-ref">' + esc(r.path) + "</span>";
      }).join("");
      return "<b>" + esc(d.title) + "</b>" +
        '<blockquote>' + lite(d.body) + "</blockquote>" +
        '<div class="sdle-refs">' + refs + "</div>" +
        '<div class="sdle-note">Retrieved from the documentation, ' +
        "not generated.</div>";
    }

    win.querySelector(".sdle-askwin-send")
       .addEventListener("click", function () { send(); });
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") send();
    });

    bubble("them",
      "<b>Ask about SDLE</b>" +
      "<div class=\"sdle-note\">This is a separate, temporary conversation. " +
      "It is not part of the run, and closing it discards it.</div>");

    ["What happens if I reject a gate?",
     "Why are requirements at the repository root?",
     "What does governance_stale mean?"].forEach(function (q) {
      var s = el("button", "sdle-sugg", esc(q));
      s.type = "button";
      s.addEventListener("click", function () { send(q); });
      body.appendChild(s);
    });

    setTimeout(function () { input.focus(); }, 50);
  }

  /* Put a question into Chainlit's composer and send it. Typing into the
     real input is the only way in — there is no public API for this, and
     faking a message client-side would not reach the server. */
  function askQuestion(q) {
    var ta = document.querySelector("#chat-input, textarea");
    if (!ta) return;
    var setter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype, "value").set;
    setter.call(ta, q);
    ta.dispatchEvent(new Event("input", { bubbles: true }));
    ta.focus();
    setTimeout(function () {
      ta.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true
      }));
    }, 60);
  }

  /* ------------------------------------------------- run panel (right) */

  function buildPanel() {
    var p = el("aside", "sdle-panel");
    p.setAttribute("aria-label", "Run detail");
    p.innerHTML =
      '<div class="sdle-panel-head">' +
        '<div class="sdle-panel-title">No run yet</div>' +
        '<div class="sdle-panel-sub">Start one to see the flow</div>' +
      "</div>" +
      '<div class="sdle-tabs"></div>' +
      '<div class="sdle-panel-body"></div>';
    return p;
  }

  function tabButton(id, label, count) {
    var b = el("button", "sdle-tab" + (panelTab === id ? " on" : ""),
      esc(label) + (count ? " <em>" + count + "</em>" : ""));
    b.type = "button";
    b.addEventListener("click", function () {
      panelTab = id;
      renderPanel(lastState);
    });
    return b;
  }

  function renderPanel(s) {
    var panel = document.querySelector(".sdle-panel");
    if (!panel || !s) return;
    lastState = s;

    panel.querySelector(".sdle-panel-title").textContent =
      s.active ? (s.project || "Run") : "No run yet";
    panel.querySelector(".sdle-panel-sub").textContent = s.active
      ? s.flow + " · Phase " + s.progress + " · " + s.gateTotal + " gates"
      : "Start one to see the flow";

    var tabs = panel.querySelector(".sdle-tabs");
    tabs.innerHTML = "";
    tabs.appendChild(tabButton("flow", "Flow"));
    tabs.appendChild(tabButton("artifacts", "Artifacts",
      (s.artifacts || []).length));
    tabs.appendChild(tabButton("engine", "Engine", (s.calls || []).length));

    var body = panel.querySelector(".sdle-panel-body");
    body.innerHTML = "";

    if (!s.active) {
      body.appendChild(el("div", "sdle-panel-empty",
        "Name a work item and choose its requirements to begin."));
      return;
    }
    if (panelTab === "flow") { renderFlow(body, s); return; }
    if (panelTab === "artifacts") { renderArtifacts(body, s); return; }
    renderEngine(body, s);
  }

  function renderFlow(body, s) {
    (s.nodes || []).forEach(function (n) {
      var row = el("div", "sdle-node " + n.state +
        (n.gate ? " gate" : "") + (n.in_poc ? "" : " out"));
      row.innerHTML =
        '<span class="sdle-dot"></span>' +
        "<span><b>" + esc(n.label) + "</b>" +
        (n.gate ? '<span class="sdle-badge">GATE ' + n.gate + "</span>" : "") +
        (s.awaiting && n.state === "current"
          ? '<span class="sdle-await">awaiting you</span>' : "") +
        "<small>" + esc(n.id) + "</small></span>";
      body.appendChild(row);
    });
    body.appendChild(el("div", "sdle-panel-foot",
      "Dimmed phases are real and governed — this proof of concept stops " +
      "after Gate 2."));
  }

  function renderArtifacts(body, s) {
    var items = s.artifacts || [];
    if (!items.length) {
      body.appendChild(el("div", "sdle-panel-empty", "Nothing generated yet."));
      return;
    }
    items.forEach(function (a) {
      var row = el("button", "sdle-art");
      row.type = "button";
      row.innerHTML =
        '<span class="sdle-art-ic">&#9670;</span>' +
        "<span><b>" + esc(a.title) + "</b><small>" + esc(a.gate) + " · " +
        a.bytes + " bytes" +
        (a.attempt > 1 ? " · attempt " + a.attempt : "") + "</small></span>";
      row.addEventListener("click", function () { openArtifact(a); });
      body.appendChild(row);
    });
  }

  function renderEngine(body, s) {
    var calls = s.calls || [];
    if (!calls.length) {
      body.appendChild(el("div", "sdle-panel-empty", "No engine calls yet."));
      return;
    }
    calls.slice().reverse().forEach(function (c) {
      var row = el("div", "sdle-call" + (c.exit === 0 ? "" : " bad"));
      row.innerHTML =
        "<span>" + (c.exit === 0 ? "&#10003;" : "&#10007;") + "</span>" +
        "<code>sdle " + esc((c.args || []).join(" ")) + "</code>" +
        (c.reason ? "<em>" + esc(c.reason) + "</em>" : "");
      body.appendChild(row);
    });
  }

  function openArtifact(a) {
    var back = el("div", "sdle-modal-back");
    var box = el("div", "sdle-modal");
    box.innerHTML =
      '<div class="sdle-modal-head"><div><b>' + esc(a.title) +
      "</b><small>" + esc(a.path) + "</small></div></div>" +
      '<div class="sdle-modal-body"><pre></pre></div>' +
      '<div class="sdle-modal-foot">' + a.bytes + " bytes" +
      (a.sha ? " · sha " + String(a.sha).slice(0, 12) + "…" : "") + "</div>";
    box.querySelector("pre").textContent = a.content || "";

    var x = el("button", "sdle-modal-x", "×");
    x.type = "button";
    box.querySelector(".sdle-modal-head").appendChild(x);
    back.appendChild(box);

    function close() { back.remove(); }
    x.addEventListener("click", close);
    back.addEventListener("click", function (e) {
      if (e.target === back) close();
    });
    document.body.appendChild(back);
  }

  function pollState() {
    fetch("/sdle/state", { cache: "no-store" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; })
      .then(function (s) { if (s) renderPanel(s); });
  }

  /* ------------------------------------------------- content sections */

  function showRoute(route) {
    var old = document.querySelector(".sdle-page");
    if (old) old.remove();
    if (!route) return;                    // Overview is the app itself

    fetch("/public/pages.json")
      .then(function (r) { return r.json(); })
      .then(function (pages) {
        var d = pages[route];
        if (!d) return;
        var cards = d.cards.map(function (c, i) {
          var n = i + 1 < 10 ? "0" + (i + 1) : String(i + 1);
          return '<article class="sdle-card">' +
            '<span class="sdle-card-i">' + n + "</span>" +
            "<h3>" + esc(c.h) + "</h3><p>" + esc(c.p) + "</p></article>";
        }).join("");

        var page = el("div", "sdle-page");
        page.innerHTML =
          '<div class="sdle-page-inner">' +
            '<button class="sdle-page-x" type="button">' +
              "← Back to the workflow</button>" +
            '<div class="sdle-eyebrow">' + esc(d.eyebrow) + "</div>" +
            "<h2>" + d.title + "</h2>" +
            '<p class="sdle-lede">' + esc(d.lede) + "</p>" +
            '<div class="sdle-cards">' + cards + "</div>" +
            (d.foot ? '<p class="sdle-page-foot">' + esc(d.foot) + "</p>" : "") +
          "</div>";
        page.querySelector(".sdle-page-x").addEventListener("click", function () {
          page.remove();
          selectNav(0);
        });
        document.body.appendChild(page);
      });
  }

  /* ----------------------------------------------------------- footer */

  function buildFooter() {
    var footer = el("footer", "sdle-footer");
    footer.appendChild(el("div", "sdle-footer-inner",
      "<span><strong>SDLE</strong> · Spec Driven Lifecycle Engine</span>" +
      "<span>Proof of concept · artifact generation is stubbed</span>"));
    return footer;
  }

  /* ------------------------------------------------------------ mount */

  function mount(logoSvg) {
    if (document.querySelector(".sdle-header")) return;
    document.body.appendChild(buildHeader(logoSvg));
    document.body.appendChild(buildRail());
    document.body.appendChild(buildPanel());
    document.body.appendChild(buildFooter());
    document.body.classList.add("sdle-chromed");
    renderPanel(lastState);
  }

  /* The gate buttons carry no data-testid and their ids are random UUIDs, so
     CSS alone cannot reach them. Tag them by their label instead, and keep
     doing it — Chainlit re-renders the action row on every ask. */
  function tagDecisions() {
    var words = { approve: "sdle-approve", reject: "sdle-reject" };
    var buttons = document.querySelectorAll("button");
    for (var i = 0; i < buttons.length; i++) {
      var b = buttons[i];
      var label = (b.textContent || "").trim().toLowerCase();
      for (var w in words) {
        if (label.indexOf(w) !== -1 && !b.classList.contains(words[w])) {
          b.classList.add(words[w]);
        }
      }
    }
  }

  function start() {
    fetch("/public/brand-logo.svg")
      .then(function (r) { return r.ok ? r.text() : ""; })
      .catch(function () { return ""; })
      .then(function (svg) {
        mount(svg || "");
        new MutationObserver(function () {
          if (!document.querySelector(".sdle-header")) mount(svg || "");
          tagDecisions();
        }).observe(document.body, { childList: true, subtree: true });
        tagDecisions();
        pollState();
        setInterval(pollState, 1200);
      });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
