# Order Search API — Specification

## Endpoint

`GET /orders/search`

| Parameter | Type | Required | Notes |
|---|---|---|---|
| `email` | string | no | Exact match, case-insensitive |
| `from` | date | no | Inclusive. With `to`, span must be <= 90 days |
| `to` | date | no | Inclusive |
| `reference` | string | no | Partial match, minimum 3 characters |
| `page` | int | no | Defaults to 1 |

At least one of `email`, `reference` or the date range must be supplied.

## Responses

| Status | When |
|---|---|
| 200 | Matches returned, 50 per page, sorted by `created_at` descending |
| 400 | No criteria given, date span over 90 days, or reference under 3 chars |
| 403 | Caller token carries no regional scope |

## Behaviour

Regional scoping is applied in the query predicate. A caller scoped to `eu`
cannot observe `us` orders through any combination of parameters, including an
empty result count.

Pagination is stable: `created_at` descending, `id` ascending as tie-break, so
a row is neither repeated nor skipped across pages.

## Acceptance

- p95 under 400ms at 50 rps against a production-shaped dataset.
- A 91-day span returns 400 with the span named in the message.
- Cross-region probing returns the same response shape as an empty result.
- Every request appears in the access log with the caller id.
