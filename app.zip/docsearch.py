"""Answer questions from the SDLE documentation — by retrieval, not generation.

This deliberately does **not** use a model. It indexes the shipped Markdown by
section, scores sections against the question with BM25, and returns the actual
prose with a citation. So an answer is always something a human wrote in the
documentation set, and the reference is checkable.

That is the honest option for a proof of concept whose generation is stubbed: a
fabricated answer about a governance engine would be worse than no answer. To
make it generative later, feed these passages to a model as context — the
retrieval layer stays as it is.
"""
from __future__ import annotations

import math
import os
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

#: Where the documentation lives. Searched, not hardcoded, so the folder can be
#: copied to another machine without editing anything: `SDLE_DOCS` wins, then a
#: bundled `sdle-docs/`, then an SDLE checkout beside or above this folder.
_HERE = Path(__file__).parent.resolve()
DOC_CANDIDATES = (
    _HERE / "sdle-docs",
    _HERE.parent / "sdle-latest",
    _HERE.parent / "sdle-git-repo" / "sdle-latest",
    _HERE.parent.parent / "sdle-git-repo" / "sdle-latest",
)


def _default_docs() -> Path:
    for c in DOC_CANDIDATES:
        if (c / "docs" / "SDLE-Reference-Guide.md").is_file():
            return c
    return DOC_CANDIDATES[0]      # reported in the "not indexed" message

STOP = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being", "of",
    "to", "in", "on", "for", "with", "and", "or", "but", "if", "as", "at",
    "by", "from", "it", "its", "this", "that", "these", "those", "what",
    "which", "who", "whom", "how", "why", "when", "where", "do", "does",
    "did", "can", "could", "should", "would", "will", "i", "you", "we",
    "there", "here", "about", "into", "than", "then", "so", "not", "no",
}


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9_]+", text.lower())
            if t not in STOP and len(t) > 1]


@dataclass
class Passage:
    path: str          # repo-relative, for the citation
    title: str         # nearest heading
    anchor: str        # GitHub-style slug
    body: str
    tokens: Counter
    length: int
    prose: float = 1.0     # share of the section that is not a fenced block

    @property
    def reference(self) -> str:
        return f"{self.path}#{self.anchor}" if self.anchor else self.path


class DocIndex:
    """A small BM25 index over Markdown sections."""

    K1, B = 1.4, 0.75

    def __init__(self, root: Path | None = None):
        self.root = Path(root or os.environ.get("SDLE_DOCS")
                 or _default_docs())
        self.passages: list[Passage] = []
        self.df: Counter = Counter()
        self.avg_len = 1.0
        self._build()

    # -- indexing --------------------------------------------------------
    def _files(self):
        if not self.root.is_dir():
            return []
        named = [self.root / "README.md",
                 self.root / "docs" / "SDLE-Reference-Guide.md",
                 self.root / "docs" / "GETTING-STARTED.md"]
        found = [p for p in named if p.is_file()]
        for sub in ("docs/architecture", "docs/workitems", "docs/lifecycle",
                    "docs/risk-and-gates", "docs/brownfield",
                    "docs/spec-kit-integration", "docs/troubleshooting",
                    "docs/tutorials"):
            d = self.root / sub
            if d.is_dir():
                found += sorted(d.glob("*.md"))
        return found

    def _build(self) -> None:
        for path in self._files():
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            rel = path.relative_to(self.root).as_posix()
            for title, body in self._split(text):
                body = body.strip()
                if len(body) < 120:            # too short to answer anything
                    continue
                toks = Counter(_tokens(title + " " + body))
                if not toks:
                    continue
                self.passages.append(Passage(
                    path=rel, title=title or path.stem,
                    anchor=_slug(title), body=body,
                    tokens=toks, length=sum(toks.values()),
                    prose=_prose_ratio(body)))
        for p in self.passages:
            self.df.update(p.tokens.keys())
        if self.passages:
            self.avg_len = sum(p.length for p in self.passages) / len(self.passages)

    @staticmethod
    def _split(text: str):
        """Split on ## / ### headings, keeping each heading with its prose."""
        parts = re.split(r"^(#{2,3})\s+(.+)$", text, flags=re.M)
        if len(parts) < 4:
            return [("", text)]
        out = [("", parts[0])]
        for i in range(1, len(parts), 3):
            out.append((parts[i + 1].strip(), parts[i + 2]))
        return out

    # -- query -----------------------------------------------------------
    def search(self, question: str, top: int = 3) -> list[tuple[Passage, float]]:
        q = _tokens(question)
        if not q or not self.passages:
            return []
        n = len(self.passages)
        scored = []
        for p in self.passages:
            score = 0.0
            for term in q:
                tf = p.tokens.get(term, 0)
                if not tf:
                    continue
                idf = math.log(1 + (n - self.df[term] + 0.5) / (self.df[term] + 0.5))
                norm = 1 - self.B + self.B * p.length / self.avg_len
                score += idf * (tf * (self.K1 + 1)) / (tf + self.K1 * norm)
            if score > 0:
                # A section that is mostly a fenced diagram or a table is
                # rarely the best *answer*, even when it matches strongly —
                # 8.1 "Phase & Gate Flow" is a mermaid block and was beating
                # the prose that actually explains rejection. Rank it lower
                # rather than dropping it: sometimes the diagram is the point.
                scored.append((p, score * (0.45 + 0.55 * p.prose)))
        scored.sort(key=lambda s: s[1], reverse=True)
        return scored[:top]

    @property
    def ready(self) -> bool:
        return bool(self.passages)


def _prose_ratio(body: str) -> float:
    fenced = sum(len(m.group(0)) for m in re.finditer(r"```.*?```", body, re.S))
    tabular = sum(len(line) for line in body.splitlines()
                  if line.lstrip().startswith("|"))
    total = max(len(body), 1)
    return max(0.0, 1.0 - (fenced + tabular) / total)


def _slug(title: str) -> str:
    s = re.sub(r"[^\w\s-]", "", title.lower()).strip()
    return re.sub(r"[\s_]+", "-", s)


def excerpt(body: str, question: str, limit: int = 700) -> str:
    """The most relevant paragraphs, not just the first ones."""
    paras = [p.strip() for p in re.split(r"\n\s*\n", body) if p.strip()]
    if not paras:
        return body[:limit]
    q = set(_tokens(question))

    def rank(par: str) -> tuple:
        overlap = len(q & set(_tokens(par)))
        # Prose answers a question; a fenced block or a table rarely does on
        # its own. Keep them eligible, just never preferred over prose.
        is_code = par.lstrip().startswith(("```", "|", "    ")) or "|---" in par
        return (-overlap, is_code)

    ranked = sorted(paras, key=rank)
    best = ranked[0]
    # Keep the document's own order for anything else that fits.
    keep, total = [], 0
    for p in paras:
        if p is best or (len(q & set(_tokens(p))) and total + len(p) < limit):
            keep.append(p)
            total += len(p)
        if total >= limit:
            break
    return "\n\n".join(keep)[:limit] if keep else best[:limit]


_INDEX: DocIndex | None = None


def index() -> DocIndex:
    global _INDEX
    if _INDEX is None:
        _INDEX = DocIndex()
    return _INDEX
